# VYRA 4.2.1 Build Pipeline Fix

This is a source-package and CI workflow revision based on VYRA app version 4.2.0.
It does not change the Android app's versionName, versionCode, filtering keywords,
classifier behaviour, or application ID.

The GitHub Actions workflow no longer invokes `android-actions/setup-android`.
Instead, it uses the Android SDK preinstalled on the GitHub Ubuntu 24.04 hosted runner,
installs/verifies the project's SDK platform and build-tools versions, provisions Gradle
8.9, and builds with JDK 17.
