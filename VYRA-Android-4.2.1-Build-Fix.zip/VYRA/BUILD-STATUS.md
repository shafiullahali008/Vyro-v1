# VYRA 4.2.0 — Build status and pipeline revision

## Source package
- Source is based on VYRA 4.2.0, including the 3D branding assets and neutral privacy labels in the keyword settings UI.
- Android application ID remains `com.nexas.safe`; app version remains 4.2.0.
- No content classifier or filtering keyword logic was changed in this build-pipeline revision.

## GitHub Actions pipeline revision
- Replaced the previous `android-actions/setup-android` action step with direct configuration of the Android SDK already installed on GitHub's Ubuntu 24.04 hosted runner.
- Uses JDK 17, Gradle 8.9, Android SDK Platform 35 and Build Tools 35.0.0.
- Uses the exact repository-root archive name `VYRA-Android-4.2.1-Build-Fix.zip`.
- Workflow path: `.github/workflows/vyra-android-build.yml`.
- Runs unit tests and assembles the debug APK, then uploads `VYRA-Android-APK`.

## Verification boundary
- The ZIP passed an integrity check and its source layout was checked.
- The workflow YAML was syntax-parsed.
- A remote GitHub Actions run has not yet been performed. This is therefore a corrected workflow package, not proof that Android compilation is already successful.
- Dependency downloads, Java compiler diagnostics and device-specific behaviour can only be confirmed during an actual build and device test.
