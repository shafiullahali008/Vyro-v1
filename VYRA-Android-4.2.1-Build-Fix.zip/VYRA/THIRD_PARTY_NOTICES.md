# Third-party notices

- TensorFlow Lite Android runtime: `org.tensorflow:tensorflow-lite:2.17.0`. See https://github.com/tensorflow/tensorflow and its license.
- The optional visual model is downloaded at runtime from https://huggingface.co/enaser/blurguard-models and is separately licensed AGPL-3.0. See `MODEL-LICENSE.md`.
- Android platform APIs and Android SDK assets are subject to their respective Google/Android terms.
