# Build VYRA 4.2.1 in GitHub Actions

1. Upload `VYRA-Android-4.2.1-Build-Fix.zip` to the repository root.
2. Create `.github/workflows/vyra-android-build.yml` using the supplied workflow file.
3. Commit both files to the `main` branch, or run **VYRA Android Build** from Actions.
4. Download the `VYRA-Android-APK` artifact after a successful run.

The workflow uses the Android SDK preinstalled on GitHub's Ubuntu 24.04 hosted runner.
It provisions Gradle 8.9, uses JDK 17, installs/verifies Android SDK platform 35 and
Build Tools 35.0.0, then runs `testDebugUnitTest` and `assembleDebug`.

The archive has a top-level `VYRA/` project folder. Its Android application ID remains
`com.nexas.safe`, and the app version remains 4.2.0; this package revision changes the
build pipeline, not the Android app's runtime version.
