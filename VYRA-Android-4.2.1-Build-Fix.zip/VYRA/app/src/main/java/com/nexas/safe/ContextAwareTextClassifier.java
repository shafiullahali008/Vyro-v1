package com.nexas.safe;

import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/** Lightweight on-device text risk heuristic. It is a filtering aid, not an AI/ML model. */
final class ContextAwareTextClassifier {
    private static final String[] PRIMARY_SIGNALS = {
            "porn", "pornography", "pornographic", "hentai", "onlyfans", "nude", "nudity",
            "pornhub", "xvideos", "xnxx", "xhamster", "redtube"
    };
    private static final String[] HIGH_CONFIDENCE_PHRASES = {
            // Strong combinations / dedicated site names. Single mentions of “porn” or
            // “pornography” are deliberately not enough: news and health pages discuss them.
            "porn video", "porn videos", "watch porn", "free porn", "hentai video",
            "hentai videos", "hentai gallery", "nude gallery", "nude photo gallery",
            "explicit photo gallery", "xxx video", "xxx videos", "adult video",
            "adult videos", "sex tape", "live cam models", "pornhub", "xvideos",
            "xnxx", "xhamster", "redtube"
    };
    private static final String[] SUPPORT_SIGNALS = {
            "erotic", "sexual content", "explicit", "adult content", "cam girl", "webcam model", "xxx"
    };
    private static final String[] SAFE_CONTEXT = {
            "news", "journalism", "court", "lawsuit", "legal", "policy", "research",
            "study", "education", "educational", "university", "school", "medical",
            "medicine", "health", "clinic", "clinical", "doctor", "patient",
            "prevention", "awareness", "history", "statistics"
    };

    private ContextAwareTextClassifier() { }

    static boolean shouldBlock(String rawText, Set<String> customKeywords) {
        if (rawText == null || rawText.trim().isEmpty()) return false;
        String text = rawText.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").trim();
        if (text.length() > 7000) text = text.substring(0, 7000);

        // A clear adult destination / explicit multiword phrase wins over page context.
        for (String phrase : HIGH_CONFIDENCE_PHRASES) {
            if (containsPhrase(text, phrase)) return true;
        }

        int safeContextHits = countDistinct(text, SAFE_CONTEXT);
        boolean contextualPage = (text.length() >= 240 && safeContextHits >= 2)
                || (text.length() >= 130 && safeContextHits >= 3);
        // Context is based on several distinct subject cues, not a lone word such as “article”.
        if (contextualPage) return false;

        int primaryHits = countDistinct(text, PRIMARY_SIGNALS);
        // “porn”, “pornography” and “pornographic” are one topic family, not three
        // independent signals. This avoids a false positive from one sentence using variants.
        int pornFamilyHits = countDistinct(text, new String[]{"porn", "pornography", "pornographic"});
        primaryHits -= Math.max(0, pornFamilyHits - 1);
        int supportHits = countDistinct(text, SUPPORT_SIGNALS);
        int customHits = 0;
        if (customKeywords != null) {
            for (String keyword : customKeywords) {
                String normalized = keyword == null ? "" : keyword.toLowerCase(Locale.ROOT).trim();
                // General topic words must not become accidental standalone page blockers.
                if (normalized.length() >= 4 && !isGenericTerm(normalized)
                        && !normalized.equals("porn") && !normalized.equals("pornography")
                        && containsPhrase(text, normalized)) customHits++;
            }
        }
        // Two independent explicit signals, or one explicit signal plus corroborating context, are required.
        return primaryHits >= 2 || (primaryHits >= 1 && supportHits >= 1)
                || (primaryHits >= 1 && customHits >= 1);
    }

    private static boolean isGenericTerm(String value) {
        return value.equals("adult") || value.equals("sex") || value.equals("sexual")
                || value.equals("erotic") || value.equals("xxx") || value.equals("explicit");
    }

    private static int countDistinct(String text, String[] terms) {
        int count = 0;
        for (String term : terms) if (containsPhrase(text, term)) count++;
        return count;
    }

    private static boolean containsPhrase(String text, String phrase) {
        if (phrase.indexOf(' ') >= 0) return text.contains(phrase);
        return Pattern.compile("(?<![a-z0-9])" + Pattern.quote(phrase) + "(?![a-z0-9])")
                .matcher(text).find();
    }
}
