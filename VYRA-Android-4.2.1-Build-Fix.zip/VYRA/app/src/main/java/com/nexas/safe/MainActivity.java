package com.nexas.safe;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.app.admin.DevicePolicyManager;
import android.media.projection.MediaProjectionManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.CheckBox;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.animation.ObjectAnimator;
import android.animation.AnimatorSet;
import android.animation.ValueAnimator;

public class MainActivity extends Activity {
    private static final int REQUEST_ADMIN = 410;
    private static final int REQUEST_IMAGE = 412;
    private static final int REQUEST_NOTIFICATIONS = 413;
    private static final int REQUEST_BLOCK_IMAGE = 414;
    private static final int REQUEST_VISUAL_CAPTURE = 415;

    private static final int BG = Color.rgb(7, 10, 19);
    private static final int PANEL = Color.rgb(15, 24, 42);
    private static final int PANEL_ALT = Color.rgb(24, 36, 59);
    private static final int OUTLINE = Color.rgb(43, 61, 91);
    private static final int WHITE = Color.rgb(239, 245, 255);
    private static final int MUTED = Color.rgb(151, 169, 198);
    private static final int TEAL = Color.rgb(90, 239, 213);
    private static final int VIOLET = Color.rgb(161, 133, 255);
    private static final int AMBER = Color.rgb(255, 194, 87);
    private static final int RED = Color.rgb(255, 99, 130);
    private int sectionIndex = 0;

    private final android.os.Handler handler = new android.os.Handler();
    private final ExecutorService scanExecutor = Executors.newSingleThreadExecutor();
    private TextView focusStatus;
    private TextView focusSubtitle;
    private TextView aiStatus;
    private TextView visualScanStatus;
    private Button visualScanButton;
    private TextView aiProgressText;
    private TextView appSelectionStatus;
    private TextView accessibilityStatus;
    private TextView adminStatus;
    private TextView signalStatus;
    private TextView shieldPill;
    private ProgressBar aiProgress;
    private EditText signalMessageInput;
    private Button startFocusButton;
    private CheckBox strictModeCheck;
    private EditText blockScreenTextInput;
    private TextView blockImageStatus;
    private TextView streakStatus;
    private TextView pointsStatus;
    private TextView bestStreakStatus;
    private TextView journeyStatus;
    private TextView journeyElapsed;
    private Button journeyButton;
    private TextView levelStatus;
    private TextView levelNextStatus;
    private ProgressBar levelProgress;
    private CountdownDial countdownDial;
    private TextView dailyGoalStatus;
    private ProgressBar dailyGoalProgress;
    private EditText intentionInput;
    private long selectedDurationMs = 45L * 60L * 1000L;
    private String selectedDurationLabel = "45 min";

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            refreshStatuses();
            handler.postDelayed(this, 1000L);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!getSharedPreferences("nexas_welcome", MODE_PRIVATE).getBoolean("complete", false)) {
            startActivity(new Intent(this, WelcomeActivity.class));
            finish();
            return;
        }
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        ensureNotificationPermission();
        buildUi();
    }

    @Override protected void onResume() {
        super.onResume();
        refreshStatuses();
        handler.removeCallbacks(ticker);
        handler.post(ticker);
    }

    @Override protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
    }

    @Override protected void onDestroy() {
        scanExecutor.shutdown();
        super.onDestroy();
    }

    private FrameLayout pageHost;
    private final ArrayList<ScrollView> pageViews = new ArrayList<>();
    private final TextView[] bottomNavLabels = new TextView[6];
    private final TextView[] bottomNavIcons = new TextView[6];
    private final LinearLayout[] bottomNavItems = new LinearLayout[6];
    private int currentPage = 0;

    private void buildUi() {
        sectionIndex = 0;
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(BG);

        LinearLayout topBar = new LinearLayout(this);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(19), dp(11), dp(17), dp(10));
        topBar.setBackgroundColor(PANEL);
        ImageView brandMark = new ImageView(this);
        brandMark.setImageResource(R.drawable.vyra_3d_icon);
        brandMark.setScaleType(ImageView.ScaleType.CENTER_CROP);
        brandMark.setBackground(round(Color.rgb(9, 14, 27), 13, Color.rgb(63, 111, 151)));
        brandMark.setClipToOutline(true);
        brandMark.setElevation(dp(8));
        LinearLayout.LayoutParams markLp = new LinearLayout.LayoutParams(dp(44), dp(44));
        markLp.rightMargin = dp(10);
        topBar.addView(brandMark, markLp);
        LinearLayout brandStack = new LinearLayout(this);
        brandStack.setOrientation(LinearLayout.VERTICAL);
        TextView brand = text("VYRA", 14, WHITE, true);
        brand.setLetterSpacing(0.075f);
        brandStack.addView(brand);
        TextView brandSub = text("A CALMER DIGITAL LIFE", 8, MUTED, true);
        brandSub.setLetterSpacing(0.13f);
        LinearLayout.LayoutParams bsp = fullWrap(); bsp.topMargin = dp(2); brandStack.addView(brandSub, bsp);
        topBar.addView(brandStack, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView settings = text("⚙", 23, MUTED, true);
        settings.setContentDescription("Open settings");
        settings.setGravity(Gravity.CENTER);
        settings.setBackground(rippleBackground(PANEL_ALT, 15, OUTLINE));
        topBar.addView(settings, new LinearLayout.LayoutParams(dp(42), dp(42)));
        settings.setOnClickListener(v -> showPage(5, true));
        shell.addView(topBar, fullWidthHeight(dp(62)));

        pageHost = new FrameLayout(this);
        pageHost.setBackgroundColor(BG);
        shell.addView(pageHost, new LinearLayout.LayoutParams(-1, 0, 1f));

        for (int i = 0; i < 7; i++) {
            ScrollView page = createPage(i);
            pageViews.add(page);
            FrameLayout.LayoutParams pageLp = new FrameLayout.LayoutParams(-1, -1);
            pageHost.addView(page, pageLp);
            page.setVisibility(View.GONE);
        }

        shell.addView(buildBottomNavigation(), fullWidthHeight(dp(68)));
        setContentView(shell);
        showPage(0, false);
        refreshStatuses();
    }

    private ScrollView createPage(int page) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(30));
        root.setBackgroundColor(BG);
        scroll.addView(root);

        switch (page) {
            case 0:
                addPageHeading(root, "YOUR SPACE", "Make room for what matters.", "A more intentional relationship with your screen starts with one small choice.");
                buildHomePage(root);
                break;
            case 1:
                addPageHeading(root, "FOCUS STUDIO", "Protect your attention.", "Choose a session, set your boundaries and let the timer carry the rhythm.");
                buildFocusPage(root);
                break;
            case 2:
                addPageHeading(root, "SMART PROTECTION", "A context-aware safety layer.", "Review the tools and permissions you choose to enable. Detection is best-effort, not infallible.");
                buildProtectionPage(root);
                break;
            case 3:
                addPageHeading(root, "YOUR PROGRESS", "Consistency over intensity.", "Small completed sessions add up. Your progress stays on this device.");
                buildProgressPage(root);
                break;
            case 4:
                addPageHeading(root, "THE CREATOR", "Meet the person behind VYRA.", "A personal introduction, interests and the ideas behind this project.");
                addCreatorProfile(root);
                buildAboutAppCard(root);
                break;
            case 5:
                addPageHeading(root, "PREFERENCES", "Make VYRA feel right.", "Manage reminders, permissions and the way the app works on your device.");
                buildSettingsPage(root);
                break;
            case 6:
                addPageHeading(root, "VYRA ARCADE", "Play with purpose.", "Short, offline-friendly mini-games for memory, attention and mental resets. No leaderboard pressure.");
                buildGamesPage(root);
                break;
        }
        TextView foot = text("VYRA   •   STAY PURE   •   YOUR TIME, YOUR CHOICE", 8, Color.rgb(105, 127, 158), true);
        foot.setGravity(Gravity.CENTER);
        foot.setLetterSpacing(0.08f);
        LinearLayout.LayoutParams fp = fullWrap(); fp.topMargin = dp(25); root.addView(foot, fp);
        return scroll;
    }

    private void addPageHeading(LinearLayout root, String eyebrow, String title, String subtitle) {
        TextView e = text(eyebrow, 9, TEAL, true);
        e.setLetterSpacing(0.17f);
        root.addView(e);
        TextView h = text(title, 29, WHITE, true);
        h.setTypeface(Typeface.create("serif", Typeface.BOLD));
        h.setLineSpacing(dp(1), 1f);
        LinearLayout.LayoutParams hp = fullWrap(); hp.topMargin = dp(8); root.addView(h, hp);
        TextView sub = text(subtitle, 12, MUTED, false);
        sub.setLineSpacing(dp(3), 1.04f);
        LinearLayout.LayoutParams sp = fullWrap(); sp.topMargin = dp(8); sp.bottomMargin = dp(10); root.addView(sub, sp);
    }

    private LinearLayout buildBottomNavigation() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(5), dp(6), dp(5), dp(5));
        nav.setBackground(round(PANEL, 0, OUTLINE));
        String[] icons = {"⌂", "◷", "◈", "✧", "🎮", "◎"};
        String[] labels = {"Home", "Focus", "Protect", "Progress", "Games", "About"};
        final int[] destinations = {0, 1, 2, 3, 6, 4};
        for (int i = 0; i < labels.length; i++) {
            final int index = destinations[i];
            final int navIndex = i;
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            item.setPadding(dp(2), dp(5), dp(2), dp(3));
            TextView icon = text(icons[i], 19, MUTED, true);
            icon.setGravity(Gravity.CENTER);
            item.addView(icon);
            TextView label = text(labels[i], 9, MUTED, true);
            label.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams llp = fullWrap(); llp.topMargin = dp(1); item.addView(label, llp);
            bottomNavLabels[navIndex] = label;
            bottomNavIcons[navIndex] = icon;
            bottomNavItems[navIndex] = item;
            nav.addView(item, new LinearLayout.LayoutParams(0, -1, 1f));
            item.setOnClickListener(v -> showPage(index, true));
        }
        return nav;
    }

    private void showPage(int page, boolean animate) {
        if (page < 0 || page >= pageViews.size()) return;
        if (currentPage == page && pageViews.get(page).getVisibility() == View.VISIBLE) return;
        for (int i = 0; i < pageViews.size(); i++) {
            ScrollView view = pageViews.get(i);
            view.animate().cancel();
            view.setVisibility(i == page ? View.VISIBLE : View.GONE);
            if (i == page) {
                view.setAlpha(animate ? 0f : 1f);
                view.setTranslationY(animate ? dp(12) : 0f);
            }
        }
        currentPage = page;
        if (animate) pageViews.get(page).animate().alpha(1f).translationY(0f).setDuration(260)
                .setInterpolator(new AccelerateDecelerateInterpolator()).start();
        for (int i = 0; i < bottomNavLabels.length; i++) {
            if (bottomNavLabels[i] != null) {
                boolean selected = new int[]{0, 1, 2, 3, 6, 4}[i] == page;
                bottomNavLabels[i].setTextColor(selected ? TEAL : MUTED);
                bottomNavLabels[i].setTypeface(Typeface.DEFAULT, selected ? Typeface.BOLD : Typeface.NORMAL);
                if (bottomNavIcons[i] != null) bottomNavIcons[i].setTextColor(selected ? TEAL : MUTED);
                if (bottomNavItems[i] != null) bottomNavItems[i].setBackground(selected
                        ? round(Color.rgb(18, 47, 58), 13, Color.rgb(28, 73, 82))
                        : round(Color.TRANSPARENT, 13, Color.TRANSPARENT));
            }
        }
        if (page == 5) {
            for (TextView label : bottomNavLabels) if (label != null) label.setTextColor(MUTED);
        }
        refreshStatuses();
    }

    private void buildHomePage(LinearLayout root) {
        LinearLayout hero = card();
        hero.setPadding(dp(20), dp(20), dp(20), dp(20));
        hero.setBackground(gradient(new int[]{Color.rgb(15, 40, 59), Color.rgb(32, 26, 68), Color.rgb(22, 20, 43)}, 25, Color.rgb(52, 79, 112)));
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout copy = new LinearLayout(this); copy.setOrientation(LinearLayout.VERTICAL);
        TextView over = text("YOUR DAILY RESET", 9, TEAL, true); over.setLetterSpacing(0.13f); copy.addView(over);
        focusStatus = text("Protection is ready", 18, WHITE, true);
        LinearLayout.LayoutParams fsp = fullWrap(); fsp.topMargin = dp(7); copy.addView(focusStatus, fsp);
        focusSubtitle = text("Start a session when you are ready to give something important your attention.", 11, MUTED, false);
        focusSubtitle.setLineSpacing(dp(2), 1.04f);
        LinearLayout.LayoutParams fsub = fullWrap(); fsub.topMargin = dp(6); copy.addView(focusSubtitle, fsub);
        row.addView(copy, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView shield = text("✦", 28, TEAL, true); shield.setGravity(Gravity.CENTER);
        shield.setBackground(gradient(new int[]{Color.rgb(29, 58, 79), Color.rgb(25, 89, 89)}, 24, Color.rgb(90, 239, 213)));
        row.addView(shield, new LinearLayout.LayoutParams(dp(58), dp(58)));
        hero.addView(row);
        LinearLayout statusRow = new LinearLayout(this); statusRow.setGravity(Gravity.CENTER_VERTICAL);
        shieldPill = text("● READY", 9, TEAL, true); shieldPill.setPadding(dp(10), dp(7), dp(10), dp(7));
        shieldPill.setBackground(round(Color.rgb(18, 47, 58), 30, Color.rgb(37, 115, 116)));
        statusRow.addView(shieldPill);
        TextView local = text("  PRIVATE BY DESIGN  ·  ON-DEVICE SETTINGS", 8, MUTED, true);
        local.setLetterSpacing(0.045f); statusRow.addView(local);
        LinearLayout.LayoutParams srp = fullWrap(); srp.topMargin = dp(17); hero.addView(statusRow, srp);
        LinearLayout.LayoutParams herop = fullWidth(); herop.height = -2; herop.topMargin = dp(13); root.addView(hero, herop);
        animateEntrance(hero, 40); pulse(shield);

        sectionHeader(root, "QUICK ACCESS", "YOUR DAILY TOOLS");
        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.VERTICAL);
        addHomeAction(actions, "Focus Studio", "Start a timed focus session", "◷", 1, TEAL);
        addHomeAction(actions, "Smart Protection", "Review detection and block-screen tools", "◈", 2, VIOLET);
        addHomeAction(actions, "Progress & Rewards", "Check goals, streaks and mini-games", "✧", 3, AMBER);
        addHomeAction(actions, "About the Creator", "Read the full creator introduction", "◎", 4, TEAL);
        root.addView(actions);

        LinearLayout guideCard = card();
        guideCard.setOrientation(LinearLayout.HORIZONTAL);
        guideCard.setGravity(Gravity.CENTER_VERTICAL);
        TextView guideGlyph = text("V", 22, WHITE, true);
        guideGlyph.setGravity(Gravity.CENTER);
        guideGlyph.setBackground(gradient(new int[]{TEAL, VIOLET}, 15, OUTLINE));
        guideCard.addView(guideGlyph, new LinearLayout.LayoutParams(dp(46), dp(46)));
        LinearLayout guideCopy = new LinearLayout(this); guideCopy.setOrientation(LinearLayout.VERTICAL); guideCopy.setPadding(dp(12), 0, 0, 0);
        guideCopy.addView(text("VYRA Offline Guide", 14, WHITE, true));
        TextView guideSub = text("Private, on-device help for focus and protection", 10, MUTED, false);
        LinearLayout.LayoutParams gslp = fullWrap(); gslp.topMargin = dp(4); guideCopy.addView(guideSub, gslp);
        guideCard.addView(guideCopy, new LinearLayout.LayoutParams(0, -2, 1f));
        guideCard.addView(text("›", 24, MUTED, false));
        LinearLayout.LayoutParams guideLp = fullWidth(); guideLp.height = -2; guideLp.topMargin = dp(10); root.addView(guideCard, guideLp);
        guideCard.setOnClickListener(v -> startActivity(new Intent(this, VyraGuideActivity.class)));
        animateEntrance(guideCard, 130);

        sectionHeader(root, "A SMALL REMINDER", "ONE STEP AT A TIME");
        LinearLayout reminderCard = card();
        reminderCard.setBackground(gradient(new int[]{Color.rgb(48, 39, 29), Color.rgb(25, 28, 42)}, 21, Color.rgb(99, 76, 51)));
        reminderCard.addView(text("You do not need a perfect day. You need a clear next step.", 16, WHITE, true));
        TextView note = text("Choose what deserves your attention, then give it a little uninterrupted time.", 11, MUTED, false);
        LinearLayout.LayoutParams np = fullWrap(); np.topMargin = dp(7); reminderCard.addView(note, np);
        root.addView(reminderCard);
        animateEntrance(reminderCard, 100);
    }

    private void addHomeAction(LinearLayout parent, String title, String detail, String glyph, int page, int tint) {
        LinearLayout tile = card();
        tile.setOrientation(LinearLayout.HORIZONTAL);
        tile.setGravity(Gravity.CENTER_VERTICAL);
        tile.setPadding(dp(15), dp(13), dp(15), dp(13));
        TextView emblem = text(glyph, 21, tint, true); emblem.setGravity(Gravity.CENTER);
        emblem.setBackground(round(tint == VIOLET ? Color.rgb(42, 34, 68) : tint == AMBER ? Color.rgb(61, 49, 30) : Color.rgb(18, 47, 58), 15, OUTLINE));
        tile.addView(emblem, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout stack = new LinearLayout(this); stack.setOrientation(LinearLayout.VERTICAL); stack.setPadding(dp(12), 0, 0, 0);
        stack.addView(text(title, 14, WHITE, true));
        TextView d = text(detail, 10, MUTED, false); LinearLayout.LayoutParams dpv = fullWrap(); dpv.topMargin = dp(4); stack.addView(d, dpv);
        tile.addView(stack, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView arrow = text("›", 24, MUTED, false); tile.addView(arrow);
        LinearLayout.LayoutParams tilep = fullWidth(); tilep.height = -2; tilep.topMargin = dp(8); parent.addView(tile, tilep);
        tile.setOnClickListener(v -> showPage(page, true));
        animateEntrance(tile, 70 + page * 22L);
    }

    private void buildFocusPage(LinearLayout root) {
        LinearLayout timerCard = card();
        LinearLayout timerHeading = new LinearLayout(this); timerHeading.setGravity(Gravity.CENTER_VERTICAL);
        TextView ttl = text("FOCUS TIMER", 10, WHITE, true); ttl.setLetterSpacing(0.12f);
        timerHeading.addView(ttl, new LinearLayout.LayoutParams(0, -2, 1f));
        timerHeading.addView(text("LIVE PROGRESS", 9, TEAL, true));
        timerCard.addView(timerHeading);
        countdownDial = new CountdownDial(this);
        LinearLayout.LayoutParams dialLp = new LinearLayout.LayoutParams(dp(242), dp(242));
        dialLp.gravity = Gravity.CENTER_HORIZONTAL; dialLp.topMargin = dp(13); timerCard.addView(countdownDial, dialLp);
        TextView timerHint = text("The ring fills as your session moves forward. Your timer uses a saved end time so it can recover after reopening the app.", 11, MUTED, false);
        timerHint.setGravity(Gravity.CENTER); timerHint.setLineSpacing(dp(2), 1.04f);
        LinearLayout.LayoutParams thp = fullWrap(); thp.topMargin = dp(7); timerCard.addView(timerHint, thp);
        LinearLayout.LayoutParams tcp = fullWidth(); tcp.height = -2; tcp.topMargin = dp(8); root.addView(timerCard, tcp);
        animateEntrance(timerCard, 50);
        ObjectAnimator bx = ObjectAnimator.ofFloat(countdownDial, View.SCALE_X, 1f, 1.012f, 1f);
        ObjectAnimator by = ObjectAnimator.ofFloat(countdownDial, View.SCALE_Y, 1f, 1.012f, 1f);
        bx.setDuration(4200L); by.setDuration(4200L); bx.setRepeatCount(ValueAnimator.INFINITE); by.setRepeatCount(ValueAnimator.INFINITE);
        AnimatorSet breathing = new AnimatorSet(); breathing.playTogether(bx, by); breathing.start();

        // Focus mode + app picker
        sectionHeader(root, "FOCUS MODE", "APP BLOCKER");
        LinearLayout focusCard = card();
        TextView focusHelp = text("Choose the apps that distract you. They will be sent away while your timed session is active.", 12, MUTED, false);
        focusCard.addView(focusHelp);
        strictModeCheck = new CheckBox(this);
        strictModeCheck.setText("STRICT MODE  •  30-second early-exit pause");
        strictModeCheck.setTextColor(WHITE);
        strictModeCheck.setTextSize(12);
        strictModeCheck.setButtonTintList(android.content.res.ColorStateList.valueOf(TEAL));
        strictModeCheck.setChecked(ProtectionPrefs.isStrictMode(this));
        LinearLayout.LayoutParams strictLp = fullWrap(); strictLp.topMargin = dp(10);
        focusCard.addView(strictModeCheck, strictLp);
        TextView strictNote = text("Opening VYRA never ends your session. Ending early requires a 30-second pause and a second confirmation. Android recovery and uninstall controls always remain available.", 11, MUTED, false);
        LinearLayout.LayoutParams strictNoteLp = fullWrap(); strictNoteLp.topMargin = dp(3); focusCard.addView(strictNote, strictNoteLp);
        Button chooseApps = button("CHOOSE APPS TO BLOCK", PANEL_ALT);
        LinearLayout.LayoutParams cap = fullWidth(); cap.topMargin = dp(13); focusCard.addView(chooseApps, cap);
        chooseApps.setOnClickListener(v -> showAppPicker());
        appSelectionStatus = text("No apps selected yet", 12, MUTED, false);
        LinearLayout.LayoutParams aslp = fullWrap(); aslp.topMargin = dp(8); focusCard.addView(appSelectionStatus, aslp);

        TextView durationLabel = text("SESSION LENGTH", 10, MUTED, true);
        LinearLayout.LayoutParams dlp = fullWrap(); dlp.topMargin = dp(17); focusCard.addView(durationLabel, dlp);
        LinearLayout durations1 = new LinearLayout(this); durations1.setOrientation(LinearLayout.HORIZONTAL);
        addDuration(durations1, "25 MIN", 25, 0);
        addDuration(durations1, "45 MIN", 45, 0);
        addDuration(durations1, "1 HOUR", 60, 0);
        LinearLayout durations2 = new LinearLayout(this); durations2.setOrientation(LinearLayout.HORIZONTAL);
        addDuration(durations2, "2 HOURS", 120, 0);
        Button customDuration = smallButton("CUSTOM", VIOLET);
        LinearLayout.LayoutParams customLp = new LinearLayout.LayoutParams(0, dp(42), 1f); customLp.rightMargin = dp(5);
        durations2.addView(customDuration, customLp);
        customDuration.setOnClickListener(v -> chooseCustomDuration());
        LinearLayout.LayoutParams d1 = fullWidth(); d1.topMargin = dp(9); focusCard.addView(durations1, d1);
        LinearLayout.LayoutParams d2 = fullWidth(); d2.topMargin = dp(7); focusCard.addView(durations2, d2);
        startFocusButton = button("START FOCUS SESSION", TEAL);
        LinearLayout.LayoutParams startLp = fullWidth(); startLp.topMargin = dp(14); focusCard.addView(startFocusButton, startLp);
        startFocusButton.setOnClickListener(v -> startFocus());
        Button endFocus = smallButton("END ACTIVE SESSION", RED);
        LinearLayout.LayoutParams endLp = fullWidth(); endLp.topMargin = dp(8); focusCard.addView(endFocus, endLp);
        endFocus.setOnClickListener(v -> confirmEndFocus());
        root.addView(focusCard);
        animateEntrance(focusCard, 200);

        sectionHeader(root, "LONG-TERM JOURNEY", "KEEP YOUR COMMITMENT RUNNING");
        LinearLayout journeyCard = card();
        journeyStatus = text("Journey not started", 16, WHITE, true);
        journeyCard.addView(journeyStatus);
        journeyElapsed = text("Your year / month / day counter will appear here.", 12, TEAL, true);
        LinearLayout.LayoutParams jelp = fullWrap(); jelp.topMargin = dp(8); journeyCard.addView(journeyElapsed, jelp);
        TextView journeyHelp = text("This is an open-ended focus journey. It keeps its original start time across app restarts and device reboots. Selected-app blocking still requires Accessibility permission and apps you choose. You can end the journey from here; Android recovery controls remain available.", 11, MUTED, false);
        LinearLayout.LayoutParams jhlp = fullWrap(); jhlp.topMargin = dp(9); journeyCard.addView(journeyHelp, jhlp);
        journeyButton = button("START LONG-TERM JOURNEY", VIOLET);
        LinearLayout.LayoutParams jblp = fullWidth(); jblp.topMargin = dp(13); journeyCard.addView(journeyButton, jblp);
        journeyButton.setOnClickListener(v -> toggleLongTermJourney());
        LinearLayout.LayoutParams jcp = fullWidth(); jcp.height = -2; jcp.topMargin = dp(8); root.addView(journeyCard, jcp);
        animateEntrance(journeyCard, 245);
    }

    private void buildProtectionPage(LinearLayout root) {
        // AI visual protection
        sectionHeader(root, "VISUAL PROTECTION", "ON-DEVICE MODEL");
        LinearLayout aiCard = card();
        aiStatus = text("AI model is not installed", 16, WHITE, true);
        aiCard.addView(aiStatus);
        TextView aiExplain = text("Text checks run locally using Accessibility. Live visual protection is a separate opt-in session: Android shows a screen-capture consent prompt and a permanent status notification. Frames are classified in memory on this device; VYRA does not save or upload screenshots.", 12, MUTED, false);
        LinearLayout.LayoutParams aelp = fullWrap(); aelp.topMargin = dp(7); aiCard.addView(aiExplain, aelp);
        aiProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        aiProgress.setMax(100); aiProgress.setProgress(0); aiProgress.setVisibility(View.GONE);
        LinearLayout.LayoutParams aplp = fullWidth(); aplp.topMargin = dp(13); aiCard.addView(aiProgress, aplp);
        aiProgressText = text("", 11, MUTED, false);
        LinearLayout.LayoutParams aptp = fullWrap(); aptp.topMargin = dp(5); aiCard.addView(aiProgressText, aptp);
        Button installModel = button("INSTALL AI MODEL", TEAL);
        LinearLayout.LayoutParams imlp = fullWidth(); imlp.topMargin = dp(14); aiCard.addView(installModel, imlp);
        installModel.setOnClickListener(v -> installModel());
        visualScanStatus = text("LIVE IMAGE SCAN: OFF", 11, AMBER, true);
        LinearLayout vsslp = fullWrap(); vsslp.topMargin = dp(16); aiCard.addView(visualScanStatus, vsslp);
        visualScanButton = button("ENABLE LIVE IMAGE PROTECTION", VIOLET);
        LinearLayout vblp = fullWidth(); vblp.topMargin = dp(9); aiCard.addView(visualScanButton, vblp);
        visualScanButton.setOnClickListener(v -> toggleVisualProtection());
        TextView visualPrivacy = text("Checks the visible display at a best-effort interval near 0.5 seconds. Actual response depends on phone speed and Android scheduling. Android's Stop screen-sharing control and VYRA's notification both end the session.", 10, MUTED, false);
        LinearLayout vplp = fullWrap(); vplp.topMargin = dp(8); aiCard.addView(visualPrivacy, vplp);
        Button testImage = button("TEST A SELECTED IMAGE", PANEL_ALT);
        LinearLayout.LayoutParams srlp = fullWidth(); srlp.topMargin = dp(9); aiCard.addView(testImage, srlp);
        testImage.setOnClickListener(v -> openImagePicker());
        TextView scanPrivacy = text("TEXT CHECKS + OPTIONAL LIVE VISUAL SCAN  •  ON-DEVICE", 9, TEAL, true);
        LinearLayout.LayoutParams lslp = fullWrap(); lslp.topMargin = dp(10); aiCard.addView(scanPrivacy, lslp);
        root.addView(aiCard);
        animateEntrance(aiCard, 130);

        // Personalised blocking screen
        sectionHeader(root, "YOUR BLOCK SCREEN", "MAKE IT YOURS");
        LinearLayout blockCustomCard = card();
        TextView customHelp = text("Choose the message that appears when VYRA catches a selected distraction. You can also add a personal image. The close control only dismisses the block screen; it does not switch Focus Mode off.", 11, MUTED, false);
        blockCustomCard.addView(customHelp);
        blockScreenTextInput = editText(ProtectionPrefs.prefs(this).getString(ProtectionPrefs.KEY_BLOCK_SCREEN_TEXT, "This content has been blocked to protect your focus."), "Your personal reminder");
        LinearLayout.LayoutParams bti = fullWidth(); bti.height = dp(84); bti.topMargin = dp(11); blockCustomCard.addView(blockScreenTextInput, bti);
        Button saveBlockText = button("SAVE BLOCK SCREEN MESSAGE", PANEL_ALT);
        LinearLayout.LayoutParams sbtlp = fullWidth(); sbtlp.topMargin = dp(8); blockCustomCard.addView(saveBlockText, sbtlp);
        saveBlockText.setOnClickListener(v -> {
            String value = blockScreenTextInput.getText().toString().trim();
            if (value.length() > 180) value = value.substring(0, 180);
            ProtectionPrefs.prefs(this).edit().putString(ProtectionPrefs.KEY_BLOCK_SCREEN_TEXT, value).apply();
            hideKeyboard(blockScreenTextInput); toast("Block screen message saved");
        });
        blockImageStatus = text("No custom block-screen image selected", 11, MUTED, false);
        LinearLayout.LayoutParams bislp = fullWrap(); bislp.topMargin = dp(10); blockCustomCard.addView(blockImageStatus, bislp);
        Button pickBlockImage = button("UPLOAD BLOCK SCREEN IMAGE", VIOLET);
        LinearLayout.LayoutParams pbilp = fullWidth(); pbilp.topMargin = dp(8); blockCustomCard.addView(pickBlockImage, pbilp);
        pickBlockImage.setOnClickListener(v -> pickBlockScreenImage());
        Button clearBlockImage = smallButton("REMOVE CUSTOM IMAGE", PANEL_ALT);
        LinearLayout.LayoutParams cbilp = fullWidth(); cbilp.topMargin = dp(7); blockCustomCard.addView(clearBlockImage, cbilp);
        clearBlockImage.setOnClickListener(v -> {
            String old = ProtectionPrefs.prefs(this).getString(ProtectionPrefs.KEY_BLOCK_SCREEN_IMAGE, "");
            if (old != null && !old.isEmpty()) try { getContentResolver().releasePersistableUriPermission(Uri.parse(old), Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
            ProtectionPrefs.prefs(this).edit().remove(ProtectionPrefs.KEY_BLOCK_SCREEN_IMAGE).apply();
            refreshStatuses(); toast("Custom image removed");
        });
        root.addView(blockCustomCard);
        animateEntrance(blockCustomCard, 270);

        // Privacy-friendly labels for the filter UI. The stored matching rules and
        // classifier are intentionally unchanged; only their on-screen presentation differs.
        sectionHeader(root, "BROWSING SAFETY", "PAGE PROTECTION SIGNALS");
        LinearLayout keywordCard = card();
        TextView ruleCount = text(ProtectionPrefs.keywords(this).size() + " PROTECTION PATTERNS ACTIVE", 15, TEAL, true);
        keywordCard.addView(ruleCount);
        TextView keywordHelp = text("VYRA checks page-level signals locally and combines them with context. General news, health and learning pages are considered separately. This is a best-effort filter, not a perfect classifier.", 12, MUTED, false);
        LinearLayout.LayoutParams khlp = fullWrap(); khlp.topMargin = dp(8); keywordCard.addView(keywordHelp, khlp);

        addSafetySignalRow(keywordCard, "Media pattern checks", "Recognizes combinations of higher-risk page and media phrases.");
        addSafetySignalRow(keywordCard, "Gallery and image cues", "Checks for groups of signals associated with restricted visual material.");
        addSafetySignalRow(keywordCard, "Context-aware matching", "Uses surrounding page context to reduce unrelated matches.");
        addSafetySignalRow(keywordCard, "Local rule processing", "Rule matching stays on this device; no online lookup is needed.");
        root.addView(keywordCard);
        animateEntrance(keywordCard, 270);


    }

    private void addSafetySignalRow(LinearLayout parent, String title, String description) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(11), dp(10), dp(11), dp(10));
        GradientDrawable background = new GradientDrawable();
        background.setColor(PANEL_ALT);
        background.setCornerRadius(dp(12));
        background.setStroke(dp(1), OUTLINE);
        row.setBackground(background);

        TextView heading = text(title, 13, WHITE, true);
        row.addView(heading);
        TextView detail = text(description, 11, MUTED, false);
        LinearLayout.LayoutParams detailLp = fullWrap();
        detailLp.topMargin = dp(4);
        row.addView(detail, detailLp);
        LinearLayout.LayoutParams rowLp = fullWidth();
        rowLp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        rowLp.topMargin = dp(8);
        parent.addView(row, rowLp);
    }

    private void buildProgressPage(LinearLayout root) {
        sectionHeader(root, "DAILY INTENTION", "SET YOUR DIRECTION");
        LinearLayout intentionCard = card();
        TextView intentionHelp = text("Write one small thing you want to finish today. Your note stays on this device.", 12, MUTED, false);
        intentionCard.addView(intentionHelp);
        intentionInput = editText(ProtectionPrefs.prefs(this).getString(ProtectionPrefs.KEY_DAILY_INTENTION, ""), "Today, I will focus on…");
        LinearLayout.LayoutParams intentionInputLp = fullWidth(); intentionInputLp.height = dp(62); intentionInputLp.topMargin = dp(10);
        intentionCard.addView(intentionInput, intentionInputLp);
        Button saveIntention = button("SAVE MY INTENTION", PANEL_ALT);
        LinearLayout.LayoutParams saveIntentionLp = fullWidth(); saveIntentionLp.topMargin = dp(8);
        intentionCard.addView(saveIntention, saveIntentionLp);
        saveIntention.setOnClickListener(v -> {
            String note = intentionInput.getText().toString().trim();
            if (note.length() > 120) note = note.substring(0, 120);
            ProtectionPrefs.prefs(this).edit().putString(ProtectionPrefs.KEY_DAILY_INTENTION, note).apply();
            hideKeyboard(intentionInput); toast("Daily intention saved");
        });
        root.addView(intentionCard);
        animateEntrance(intentionCard, 215);

        sectionHeader(root, "DAILY FOCUS GOAL", "SMALL STEPS ADD UP");
        LinearLayout goalCard = card();
        dailyGoalStatus = text("0 / 120 minutes today", 14, WHITE, true);
        goalCard.addView(dailyGoalStatus);
        dailyGoalProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        dailyGoalProgress.setMax(100); dailyGoalProgress.setProgress(0);
        dailyGoalProgress.setProgressTintList(android.content.res.ColorStateList.valueOf(TEAL));
        dailyGoalProgress.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(37, 53, 78)));
        LinearLayout.LayoutParams goalProgressLp = fullWidth(); goalProgressLp.topMargin = dp(12); goalCard.addView(dailyGoalProgress, goalProgressLp);
        TextView goalHelp = text("Choose a daily target. Completed focus sessions add to your progress.", 11, MUTED, false);
        LinearLayout.LayoutParams goalHelpLp = fullWrap(); goalHelpLp.topMargin = dp(8); goalCard.addView(goalHelp, goalHelpLp);
        LinearLayout goalButtons = new LinearLayout(this); goalButtons.setOrientation(LinearLayout.HORIZONTAL);
        int[] goals = new int[]{60, 120, 180, 240};
        for (int minutes : goals) {
            Button goalButton = smallButton((minutes / 60) + " HR", PANEL_ALT);
            LinearLayout.LayoutParams goalButtonLp = new LinearLayout.LayoutParams(0, dp(42), 1f); goalButtonLp.rightMargin = dp(5);
            goalButtons.addView(goalButton, goalButtonLp);
            goalButton.setOnClickListener(v -> {
                ProtectionPrefs.prefs(this).edit().putInt(ProtectionPrefs.KEY_DAILY_GOAL_MINUTES, minutes).apply();
                refreshStatuses(); toast("Daily goal set to " + (minutes / 60) + " hour(s)");
            });
        }
        LinearLayout.LayoutParams goalButtonsLp = fullWidth(); goalButtonsLp.topMargin = dp(10); goalCard.addView(goalButtons, goalButtonsLp);
        root.addView(goalCard);
        animateEntrance(goalCard, 230);

        // Streaks, rewards and quick focus games
        sectionHeader(root, "FOCUS JOURNEY & REWARDS", "YOUR LONG-TERM COMMITMENT");
        LinearLayout rewardsCard = card();
        LinearLayout rewardStats = new LinearLayout(this);
        rewardStats.setOrientation(LinearLayout.HORIZONTAL);
        streakStatus = text("Journey not started", 15, TEAL, true);
        pointsStatus = text("0 pts", 15, VIOLET, true);
        bestStreakStatus = text("NOT STARTED", 15, AMBER, true);
        rewardStats.addView(streakStatus, new LinearLayout.LayoutParams(0, -2, 1f));
        rewardStats.addView(pointsStatus, new LinearLayout.LayoutParams(0, -2, 1f));
        rewardStats.addView(bestStreakStatus, new LinearLayout.LayoutParams(0, -2, 1f));
        rewardsCard.addView(rewardStats);
        TextView rewardHelp = text("This journey counter starts only when Long-term Focus Journey is enabled. It tracks calendar years, months, days and time. Completed timed sessions continue to earn points separately.", 11, MUTED, false);
        LinearLayout.LayoutParams rhp = fullWrap(); rhp.topMargin = dp(10); rewardsCard.addView(rewardHelp, rhp);
        LinearLayout gameRow = new LinearLayout(this); gameRow.setOrientation(LinearLayout.HORIZONTAL);
        Button breathe = button("BREATH RESET", PANEL_ALT);
        Button memory = button("PATTERN GAME", PANEL_ALT);
        LinearLayout.LayoutParams gameLp1 = new LinearLayout.LayoutParams(0, dp(48), 1f); gameLp1.rightMargin = dp(5);
        LinearLayout.LayoutParams gameLp2 = new LinearLayout.LayoutParams(0, dp(48), 1f); gameLp2.leftMargin = dp(5);
        gameRow.addView(breathe, gameLp1); gameRow.addView(memory, gameLp2);
        LinearLayout.LayoutParams grlp = fullWidth(); grlp.topMargin = dp(13); rewardsCard.addView(gameRow, grlp);
        breathe.setOnClickListener(v -> startBreathingReset());
        memory.setOnClickListener(v -> startPatternGame());
        Button quickSprint = button("START 25-MIN QUICK SPRINT", TEAL);
        LinearLayout.LayoutParams qslp = fullWidth(); qslp.topMargin = dp(9); rewardsCard.addView(quickSprint, qslp);
        quickSprint.setOnClickListener(v -> {
            selectedDurationMs = 25L * 60L * 1000L;
            selectedDurationLabel = "25 min quick sprint";
            startFocus();
        });
        root.addView(rewardsCard);
        animateEntrance(rewardsCard, 235);

        sectionHeader(root, "LONG-TERM ACHIEVEMENTS", "LEVEL UP THROUGH CONSISTENCY");
        LinearLayout levelsCard = card();
        levelStatus = text("LEVEL 0  •  JOURNEY NOT STARTED", 15, TEAL, true);
        levelsCard.addView(levelStatus);
        levelNextStatus = text("Start a Long-term Journey to unlock your first milestone.", 11, MUTED, false);
        LinearLayout.LayoutParams lnsp = fullWrap(); lnsp.topMargin = dp(8); levelsCard.addView(levelNextStatus, lnsp);
        levelProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        levelProgress.setMax(100); levelProgress.setProgress(0);
        levelProgress.setProgressTintList(android.content.res.ColorStateList.valueOf(VIOLET));
        levelProgress.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(37, 53, 78)));
        LinearLayout.LayoutParams lprp = fullWidth(); lprp.topMargin = dp(12); levelsCard.addView(levelProgress, lprp);
        TextView levelList = text("L1  1 day     ·     L2  7 days     ·     L3  1 month\nL4  3 months  ·   L5  6 months  ·     L6  1 year\nL7  2 years   ·     L8  5 years      ·     L9  10 years", 10, MUTED, false);
        LinearLayout.LayoutParams llp = fullWrap(); llp.topMargin = dp(12); levelsCard.addView(levelList, llp);
        root.addView(levelsCard);
        animateEntrance(levelsCard, 260);

    }

    private void open3DGame(String mode) {
        Intent intent = new Intent(this, Arcade3DActivity.class);
        intent.putExtra("game_mode", mode);
        startActivity(intent);
    }

    private void buildGamesPage(LinearLayout root) {
        addArcadeHero(root);
        sectionHeader(root, "FLAGSHIP 3D EXPERIENCES", "ENTER THE ARCADE");
        addGameCard(root, "🏃", "Temple Sprint 3D", "ENDLESS RUNNER • REAL-TIME 3D", "Run through a procedural temple course. Swipe between lanes, jump barriers, slide under gates and collect energy orbs. Speed increases as the run goes on.", "PLAY TEMPLE SPRINT", VIOLET, () -> open3DGame("runner"));
        addGameCard(root, "◉", "Orbit Roll 3D", "PHYSICS ARCADE • REAL-TIME 3D", "Steer a glowing orb across a shifting course, collect light orbs and avoid obstacles. Swipe between lanes, build distance and unlock higher scores. Entirely offline.", "PLAY ORBIT ROLL", TEAL, () -> open3DGame("orb"));
        sectionHeader(root, "CLASSIC BRAIN TRAINING", "MEMORY & ATTENTION");
        addGameCard(root, "◉", "Pattern Memory", "MEMORY • EASY TO HARD", "Remember a sequence, then reproduce it. Trains short-term recall.", "PLAY MEMORY", VIOLET, this::startPatternGame);
        addGameCard(root, "⚡", "Reaction Tap", "REACTION • QUICK ROUND", "Wait for the GO signal, then tap. Early taps do not count.", "PLAY REACTION", TEAL, this::startReactionGame);
        addGameCard(root, "▦", "Tile Match", "MEMORY • 4 PAIRS", "Reveal tiles and find matching pairs. A quiet visual-memory challenge.", "PLAY TILE MATCH", VIOLET, this::startTileMatchGame);
        addGameCard(root, "◇", "Odd One Out", "VISUAL SCAN • 5 ROUNDS", "Find the one symbol that differs from the rest.", "FIND THE ODD ONE", RED, this::startOddOneOutGame);

        sectionHeader(root, "LOGIC & LEARNING", "SMALL BRAIN WORKOUTS");
        addGameCard(root, "＋", "Mental Maths", "MATHS • 5 QUESTIONS", "Solve five quick arithmetic questions at your own pace.", "PLAY MATHS", AMBER, this::startMathGame);
        addGameCard(root, "⌁", "Number Sequence", "LOGIC • 5 PUZZLES", "Study the pattern and enter the next number.", "SOLVE SEQUENCES", TEAL, this::startNumberSequenceGame);
        addGameCard(root, "✎", "Word Scramble", "WORDS • 5 ROUNDS", "Unscramble five everyday words. Take your time.", "PLAY WORDS", RED, this::startWordGame);
        addGameCard(root, "?", "Quick Quiz", "KNOWLEDGE • 5 QUESTIONS", "A short offline quiz with general-knowledge questions.", "START QUIZ", VIOLET, this::startQuickQuizGame);
        addGameCard(root, "●", "Color Match", "VISUAL • 5 ROUNDS", "Match the named color to the correct color tile.", "PLAY COLOR MATCH", AMBER, this::startColorMatchGame);

        sectionHeader(root, "RESET & RECOVER", "A CALM PAUSE COUNTS TOO");
        addGameCard(root, "☁", "Breathing Reset", "WELLBEING • NO SCORE", "A short guided pause between tasks. No score and no timer pressure.", "START RESET", TEAL, this::startBreathingReset);

        sectionHeader(root, "YOUR ARCADE", "PRIVATE BY DESIGN");
        LinearLayout note = card();
        note.addView(text("Your scores and earned points stay on this device. Games work offline and are designed as short breaks, not endless feeds. There are no public leaderboards, ads or social comparisons. You can close any game whenever you like.", 12, MUTED, false));
        LinearLayout.LayoutParams np = fullWidth(); np.topMargin = dp(7); note.addView(smallButton("VIEW MY PROGRESS", PANEL_ALT), np);
        note.getChildAt(1).setOnClickListener(v -> showPage(3, true));
        root.addView(note);
    }

    private void addArcadeHero(LinearLayout root) {
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.HORIZONTAL);
        hero.setGravity(Gravity.CENTER_VERTICAL);
        hero.setPadding(dp(18), dp(18), dp(16), dp(18));
        hero.setBackground(gradient(new int[]{Color.rgb(15, 40, 59), Color.rgb(32, 26, 68)}, 24, Color.rgb(52, 79, 112)));
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        TextView eyebrow = text("VYRA ARCADE  /  VOL. 01", 9, TEAL, true);
        eyebrow.setLetterSpacing(0.12f);
        copy.addView(eyebrow);
        TextView headline = text("A little play.\nA sharper mind.", 22, WHITE, true);
        headline.setTypeface(Typeface.create("serif", Typeface.BOLD));
        LinearLayout.LayoutParams hlp = fullWrap(); hlp.topMargin = dp(7); copy.addView(headline, hlp);
        TextView subtitle = text("Two playable 3D arcade prototypes plus offline brain training.", 11, MUTED, false);
        LinearLayout.LayoutParams slp = fullWrap(); slp.topMargin = dp(6); copy.addView(subtitle, slp);
        LinearLayout stats = new LinearLayout(this);
        stats.setGravity(Gravity.CENTER_VERTICAL);
        TextView modes = text("2 FLAGSHIP 3D GAMES", 9, VIOLET, true);
        modes.setLetterSpacing(0.07f);
        TextView offline = text("  •  ON-DEVICE PLAY", 9, TEAL, true);
        offline.setLetterSpacing(0.06f);
        LinearLayout.LayoutParams stp = fullWrap(); stp.topMargin = dp(12); stats.addView(modes); stats.addView(offline); copy.addView(stats, stp);
        hero.addView(copy, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView orb = text("✦", 34, Color.WHITE, true);
        orb.setGravity(Gravity.CENTER);
        orb.setBackground(gradient(new int[]{VIOLET, TEAL}, 25, Color.rgb(43, 61, 91)));
        orb.setElevation(dp(8));
        hero.addView(orb, new LinearLayout.LayoutParams(dp(70), dp(70)));
        LinearLayout.LayoutParams hp = fullWidth(); hp.height = -2; hp.bottomMargin = dp(7); root.addView(hero, hp);
        animateEntrance(hero, 65);
        pulse(orb);

        LinearLayout statsRow = new LinearLayout(this);
        statsRow.setOrientation(LinearLayout.HORIZONTAL);
        int points = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_FOCUS_POINTS, 0);
        int completed = ProtectionPrefs.prefs(this).getInt("arcade_completed_games", 0);
        addStat(statsRow, "GAME MODES", "11 + RESET", VIOLET);
        addStat(statsRow, "COMPLETED", String.valueOf(completed), TEAL);
        addStat(statsRow, "TOTAL POINTS", String.valueOf(points), AMBER);
        LinearLayout.LayoutParams srp = fullWidth(); srp.height = dp(76); srp.topMargin = dp(9); root.addView(statsRow, srp);
    }

    private void addGameCard(LinearLayout root, String icon, String title, String category, String description, String action, int accent, Runnable play) {
        LinearLayout c = card();
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView badge = text(icon, 22, accent, true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(gradient(new int[]{blend(accent, Color.WHITE, 0.84f), blend(accent, Color.WHITE, 0.93f)}, 15, blend(accent, Color.WHITE, 0.72f)));
        LinearLayout.LayoutParams badgeLp = new LinearLayout.LayoutParams(dp(48), dp(48));
        badgeLp.rightMargin = dp(12);
        head.addView(badge, badgeLp);
        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        TextView t = text(title, 16, WHITE, true);
        labels.addView(t);
        TextView cat = text(category, 8, accent, true);
        cat.setLetterSpacing(0.10f);
        LinearLayout.LayoutParams catLp = fullWrap(); catLp.topMargin = dp(4); labels.addView(cat, catLp);
        head.addView(labels, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView arrow = text("↗", 18, MUTED, true); arrow.setGravity(Gravity.CENTER); head.addView(arrow, new LinearLayout.LayoutParams(dp(28), dp(38)));
        c.addView(head);
        TextView d = text(description, 11, MUTED, false);
        d.setLineSpacing(dp(2), 1.02f);
        LinearLayout.LayoutParams dp1 = fullWrap(); dp1.topMargin = dp(11); c.addView(d, dp1);
        Button b = button(action, accent);
        LinearLayout.LayoutParams bp = fullWidth(); bp.topMargin = dp(13); c.addView(b, bp);
        b.setOnClickListener(v -> play.run());
        c.setOnClickListener(v -> play.run());
        LinearLayout.LayoutParams cp = fullWidth(); cp.height = -2; cp.bottomMargin = dp(11); root.addView(c, cp);
        animateEntrance(c, 115 + (root.getChildCount() % 6) * 34L);
    }

    private void showArcadeResult(String title, int score, int total, String game, int reward) {
        recordArcadeCompletion(game);
        String message = "You scored " + score + " / " + total + ".";
        if (score >= Math.max(2, total / 2)) {
            awardMiniGamePoints(reward, game);
            message += "\n\n" + reward + " focus points added to your local total.";
        } else {
            message += "\n\nGood try. You can revisit this game later.";
        }
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("Done", null).show();
    }

    private void recordArcadeCompletion(String game) {
        int completed = ProtectionPrefs.prefs(this).getInt("arcade_completed_games", 0);
        ProtectionPrefs.prefs(this).edit().putInt("arcade_completed_games", completed + 1).apply();
    }

    private void awardMiniGamePoints(int amount, String game) {
        int current = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_FOCUS_POINTS, 0);
        int earned = ProtectionPrefs.prefs(this).getInt("arcade_earned_points", 0);
        ProtectionPrefs.prefs(this).edit()
                .putInt(ProtectionPrefs.KEY_FOCUS_POINTS, current + amount)
                .putInt("arcade_earned_points", earned + amount)
                .apply();
        refreshStatuses();
        toast(game + " complete • +" + amount + " points");
    }

    private void startReactionGame() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18), dp(20), dp(18), dp(20));
        TextView status = text("Tap START, then wait for the signal.", 17, WHITE, true); status.setGravity(Gravity.CENTER);
        Button tap = button("START", TEAL); LinearLayout.LayoutParams bp = fullWidth(); bp.topMargin = dp(15); box.addView(status, fullWidth()); box.addView(tap, bp);
        final AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Reaction Tap").setView(box).setNegativeButton("Close", null).create();
        final boolean[] waiting = {false}; final boolean[] ready = {false}; final long[] start = {0L}; final Runnable[] signal = new Runnable[1];
        tap.setOnClickListener(v -> {
            if (!waiting[0] && !ready[0]) {
                waiting[0] = true; tap.setText("WAIT…"); status.setText("Stay ready. Don't tap yet.");
                int delay = 1500 + new java.util.Random().nextInt(3000);
                signal[0] = () -> { if (dialog.isShowing()) { ready[0] = true; waiting[0] = false; start[0] = android.os.SystemClock.elapsedRealtime(); status.setText("GO! TAP NOW"); tap.setText("TAP!"); } };
                handler.postDelayed(signal[0], delay);
            } else if (waiting[0]) {
                handler.removeCallbacks(signal[0]); waiting[0] = false; status.setText("Too early. Try again."); tap.setText("TRY AGAIN");
            } else if (ready[0]) {
                long ms = android.os.SystemClock.elapsedRealtime() - start[0]; ready[0] = false;
                status.setText("Your reaction time: " + ms + " ms"); tap.setText("PLAY AGAIN");
                recordArcadeCompletion("Reaction Tap");
                if (ms < 1000) awardMiniGamePoints(2, "Reaction Tap");
            }
        });
        dialog.setOnDismissListener(d -> { if (signal[0] != null) handler.removeCallbacks(signal[0]); });
        dialog.show();
    }

    private void startMathGame() {
        final int[] round = {0}, score = {0};
        final EditText answer = editText("", "Your answer");
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18), dp(16), dp(18), dp(16));
        TextView question = text("", 23, TEAL, true); question.setGravity(Gravity.CENTER);
        TextView progress = text("Question 1 of 5", 11, MUTED, false);
        box.addView(progress); LinearLayout.LayoutParams q = fullWidth(); q.topMargin = dp(12); box.addView(question, q);
        LinearLayout.LayoutParams a = fullWidth(); a.topMargin = dp(12); box.addView(answer, a);
        final int[] expected = {0};
        Runnable next = () -> { int x = 2 + new java.util.Random().nextInt(18), y = 2 + new java.util.Random().nextInt(12); expected[0] = x * y; question.setText(x + " × " + y + " = ?"); progress.setText("Question " + (round[0] + 1) + " of 5"); answer.setText(""); };
        next.run();
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Mental Maths").setView(box).setNegativeButton("Close", null).setPositiveButton("Check", null).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            try { if (Integer.parseInt(answer.getText().toString().trim()) == expected[0]) score[0]++; } catch (Exception ignored) { answer.setError("Enter a number"); return; }
            round[0]++;
            if (round[0] >= 5) { recordArcadeCompletion("Mental Maths"); if (score[0] >= 3) awardMiniGamePoints(3, "Mental Maths"); new AlertDialog.Builder(this).setMessage("You scored " + score[0] + " / 5").setPositiveButton("Done", null).show(); dialog.dismiss(); }
            else next.run();
        }));
        dialog.show();
    }

    private void startWordGame() {
        final String[][] words = {{"FOCUS", "SUCOF"}, {"PEACE", "EACPE"}, {"LEARN", "NRAEL"}, {"PHONE", "NEHOP"}, {"BRAVE", "VABRE"}};
        final int[] index = {0}, score = {0};
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18), dp(16), dp(18), dp(16));
        TextView scrambled = text("", 25, VIOLET, true); scrambled.setGravity(Gravity.CENTER);
        TextView count = text("Word 1 of 5", 11, MUTED, false);
        EditText answer = editText("", "Unscrambled word"); box.addView(count); LinearLayout.LayoutParams sp = fullWidth(); sp.topMargin = dp(12); box.addView(scrambled, sp); LinearLayout.LayoutParams ap = fullWidth(); ap.topMargin = dp(10); box.addView(answer, ap);
        Runnable show = () -> { count.setText("Word " + (index[0] + 1) + " of 5"); scrambled.setText(words[index[0]][1]); answer.setText(""); };
        show.run();
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Word Scramble").setView(box).setNegativeButton("Close", null).setPositiveButton("Check", null).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (answer.getText().toString().trim().equalsIgnoreCase(words[index[0]][0])) score[0]++;
            index[0]++;
            if (index[0] == words.length) { recordArcadeCompletion("Word Scramble"); if (score[0] >= 3) awardMiniGamePoints(3, "Word Scramble"); new AlertDialog.Builder(this).setMessage("You solved " + score[0] + " / 5 words").setPositiveButton("Done", null).show(); dialog.dismiss(); }
            else show.run();
        }));
        dialog.show();
    }

    private void startTileMatchGame() {
        final String[] faces = {"✦", "●", "◆", "♥", "▲", "☀", "✿", "☘"};
        final ArrayList<String> deck = new ArrayList<>();
        for (String face : faces) { deck.add(face); deck.add(face); }
        Collections.shuffle(deck);
        final boolean[] matched = new boolean[deck.size()];
        final int[] first = {-1}, matches = {0};
        final boolean[] locked = {false};
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(14), dp(14), dp(14), dp(14));
        TextView hint = text("Find all eight pairs. Tap two tiles to reveal them.", 12, MUTED, false);
        box.addView(hint);
        TextView status = text("0 / 8 pairs found", 11, TEAL, true); LinearLayout.LayoutParams st = fullWrap(); st.topMargin = dp(8); box.addView(status, st);
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4); grid.setRowCount(4);
        LinearLayout.LayoutParams glp = fullWidth(); glp.height = -2; glp.topMargin = dp(12); box.addView(grid, glp);
        final AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Tile Match").setView(box).setNegativeButton("Close", null).create();
        final Runnable[] hideMismatch = {null};
        for (int i = 0; i < deck.size(); i++) {
            final int index = i;
            Button tile = button("?", PANEL_ALT);
            tile.setTextSize(20);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 0; lp.height = dp(52); lp.columnSpec = GridLayout.spec(i % 4, 1f); lp.rowSpec = GridLayout.spec(i / 4);
            lp.setMargins(dp(3), dp(3), dp(3), dp(3));
            grid.addView(tile, lp);
            tile.setOnClickListener(v -> {
                if (locked[0] || matched[index] || index == first[0]) return;
                tile.setText(deck.get(index)); tile.setBackground(round(Color.rgb(23, 49, 58), 12, TEAL));
                if (first[0] < 0) { first[0] = index; return; }
                int previous = first[0]; first[0] = -1;
                if (deck.get(previous).equals(deck.get(index))) {
                    matched[previous] = true; matched[index] = true; matches[0]++;
                    View old = grid.getChildAt(previous); View current = grid.getChildAt(index);
                    old.setAlpha(0.55f); current.setAlpha(0.55f);
                    status.setText(matches[0] + " / 8 pairs found");
                    if (matches[0] == 8) { dialog.dismiss(); recordArcadeCompletion("Tile Match"); awardMiniGamePoints(4, "Tile Match"); new AlertDialog.Builder(this).setTitle("All pairs found").setMessage("Nice recall. All eight pairs are matched.").setPositiveButton("Done", null).show(); }
                } else {
                    locked[0] = true;
                    hideMismatch[0] = () -> {
                        if (!dialog.isShowing()) return;
                        Button a = (Button) grid.getChildAt(previous); Button b = (Button) grid.getChildAt(index);
                        a.setText("?"); b.setText("?"); a.setBackground(rippleBackground(PANEL_ALT, 14, OUTLINE)); b.setBackground(rippleBackground(PANEL_ALT, 14, OUTLINE)); locked[0] = false;
                    };
                    handler.postDelayed(hideMismatch[0], 700L);
                }
            });
        }
        dialog.setOnDismissListener(d -> { if (hideMismatch[0] != null) handler.removeCallbacks(hideMismatch[0]); });
        dialog.show();
    }

    private void startOddOneOutGame() {
        final int[] round = {0}, score = {0}, odd = {0};
        final String[] common = {"●", "◆", "▲", "■", "✦"};
        final String[] different = {"◇", "○", "△", "□", "✧"};
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16), dp(16), dp(16), dp(16));
        TextView instruction = text("Find the symbol that is different.", 12, MUTED, false); box.addView(instruction);
        TextView progress = text("ROUND 1 OF 5", 9, TEAL, true); LinearLayout.LayoutParams pl = fullWrap(); pl.topMargin = dp(8); box.addView(progress, pl);
        GridLayout grid = new GridLayout(this); grid.setColumnCount(3); LinearLayout.LayoutParams gl = fullWidth(); gl.height = -2; gl.topMargin = dp(12); box.addView(grid, gl);
        final AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Odd One Out").setView(box).setNegativeButton("Close", null).create();
        final Runnable[] next = new Runnable[1];
        next[0] = () -> {
            progress.setText("ROUND " + (round[0] + 1) + " OF 5"); grid.removeAllViews();
            int family = round[0] % common.length; odd[0] = new java.util.Random().nextInt(9);
            for (int i = 0; i < 9; i++) {
                final int index = i;
                Button cell = button(i == odd[0] ? different[family] : common[family], PANEL_ALT); cell.setTextSize(25);
                GridLayout.LayoutParams cp = new GridLayout.LayoutParams(); cp.width = 0; cp.height = dp(57); cp.columnSpec = GridLayout.spec(i % 3, 1f); cp.rowSpec = GridLayout.spec(i / 3); cp.setMargins(dp(4), dp(4), dp(4), dp(4));
                grid.addView(cell, cp);
                cell.setOnClickListener(v -> {
                    if (index == odd[0]) score[0]++;
                    round[0]++;
                    if (round[0] >= 5) { dialog.dismiss(); showArcadeResult("Visual scan complete", score[0], 5, "Odd One Out", 3); }
                    else next[0].run();
                });
            }
        };
        next[0].run(); dialog.show();
    }

    private void startNumberSequenceGame() {
        final int[][] puzzles = {{2,4,6,8,10},{3,6,12,24,48},{1,1,2,3,5,8},{5,10,20,40,80},{1,4,9,16,25}};
        final int[] expected = {10,48,8,80,25};
        final int[] round = {0}, score = {0};
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18), dp(16), dp(18), dp(16));
        TextView progress = text("PUZZLE 1 OF 5", 9, TEAL, true);
        TextView sequence = text("", 24, VIOLET, true); sequence.setGravity(Gravity.CENTER);
        TextView help = text("Find the next number in the pattern.", 12, MUTED, false);
        EditText answer = editText("", "Next number");
        box.addView(progress); LinearLayout.LayoutParams q = fullWidth(); q.height = dp(58); q.topMargin = dp(12); box.addView(sequence, q); LinearLayout.LayoutParams hp = fullWrap(); hp.topMargin = dp(8); box.addView(help, hp); LinearLayout.LayoutParams ap = fullWidth(); ap.topMargin = dp(12); box.addView(answer, ap);
        Runnable[] show = new Runnable[1];
        show[0] = () -> { progress.setText("PUZZLE " + (round[0] + 1) + " OF 5"); int[] puzzle = puzzles[round[0]]; StringBuilder b = new StringBuilder(); for (int i=0;i<puzzle.length-1;i++) { if(i>0)b.append("   "); b.append(puzzle[i]); } b.append("   ?"); sequence.setText(b.toString()); answer.setText(""); };
        show[0].run();
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Number Sequence").setView(box).setNegativeButton("Close", null).setPositiveButton("Check", null).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            try { if (Integer.parseInt(answer.getText().toString().trim()) == expected[round[0]]) score[0]++; }
            catch (Exception ex) { answer.setError("Enter a whole number"); return; }
            round[0]++;
            if (round[0] == 5) { dialog.dismiss(); showArcadeResult("Sequence complete", score[0], 5, "Number Sequence", 4); }
            else show[0].run();
        }));
        dialog.show();
    }

    private void startQuickQuizGame() {
        final String[] questions = {
                "Which planet is known as the Red Planet?",
                "How many sides does a hexagon have?",
                "Which gas do plants absorb from the air?",
                "What is the largest ocean on Earth?",
                "Which instrument measures temperature?"
        };
        final String[][] options = {
                {"Venus", "Mars", "Jupiter", "Mercury"},
                {"Five", "Six", "Seven", "Eight"},
                {"Oxygen", "Nitrogen", "Carbon dioxide", "Hydrogen"},
                {"Atlantic", "Indian", "Arctic", "Pacific"},
                {"Barometer", "Thermometer", "Compass", "Ruler"}
        };
        final int[] correct = {1,1,2,3,1};
        final int[] round = {0}, score = {0};
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16), dp(14), dp(16), dp(14));
        TextView progress = text("QUESTION 1 OF 5", 9, TEAL, true);
        TextView question = text("", 19, WHITE, true); question.setLineSpacing(dp(2),1f);
        LinearLayout choices = new LinearLayout(this); choices.setOrientation(LinearLayout.VERTICAL);
        box.addView(progress); LinearLayout.LayoutParams qp = fullWrap(); qp.topMargin = dp(13); qp.bottomMargin = dp(12); box.addView(question, qp); box.addView(choices);
        final AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Quick Quiz").setView(box).setNegativeButton("Close", null).create();
        Runnable[] show = new Runnable[1];
        show[0] = () -> {
            progress.setText("QUESTION " + (round[0] + 1) + " OF 5"); question.setText(questions[round[0]]); choices.removeAllViews();
            for (int i=0;i<4;i++) { final int choice=i; Button b=smallButton(options[round[0]][i], PANEL_ALT); LinearLayout.LayoutParams bp=fullWidth(); bp.bottomMargin=dp(7); choices.addView(b,bp); b.setOnClickListener(v->{ if(choice==correct[round[0]]) score[0]++; round[0]++; if(round[0]>=5){dialog.dismiss();showArcadeResult("Quiz finished",score[0],5,"Quick Quiz",3);}else show[0].run(); }); }
        };
        show[0].run(); dialog.show();
    }

    private void startColorMatchGame() {
        final String[] names = {"TEAL", "VIOLET", "AMBER", "ROSE"};
        final int[] colors = {TEAL, VIOLET, AMBER, RED};
        final int[] round = {0}, score = {0}, target = {0};
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16), dp(16), dp(16), dp(16));
        TextView progress = text("ROUND 1 OF 5", 9, TEAL, true);
        TextView prompt = text("MATCH THIS COLOR", 12, MUTED, true); prompt.setGravity(Gravity.CENTER);
        TextView targetName = text("", 24, WHITE, true); targetName.setGravity(Gravity.CENTER);
        LinearLayout swatches = new LinearLayout(this); swatches.setOrientation(LinearLayout.HORIZONTAL); swatches.setGravity(Gravity.CENTER);
        box.addView(progress); LinearLayout.LayoutParams pp=fullWidth(); pp.height=dp(32); pp.topMargin=dp(8); box.addView(prompt,pp); LinearLayout.LayoutParams tp=fullWidth(); tp.height=dp(55); tp.topMargin=dp(4); box.addView(targetName,tp); LinearLayout.LayoutParams sp=fullWidth(); sp.height=dp(58); sp.topMargin=dp(12); box.addView(swatches,sp);
        final AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Color Match").setView(box).setNegativeButton("Close", null).create();
        Runnable[] show = new Runnable[1];
        show[0] = () -> {
            target[0]=new java.util.Random().nextInt(4); progress.setText("ROUND " + (round[0]+1) + " OF 5"); targetName.setText(names[target[0]]); targetName.setTextColor(colors[target[0]]); swatches.removeAllViews();
            for(int i=0;i<4;i++){ final int choice=i; TextView swatch=text("",12,Color.WHITE,true); swatch.setGravity(Gravity.CENTER); swatch.setContentDescription(names[i]); swatch.setBackground(round(colors[i],14,Color.WHITE)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(52),1f); lp.setMargins(dp(4),0,dp(4),0); swatches.addView(swatch,lp); swatch.setOnClickListener(v->{if(choice==target[0])score[0]++;round[0]++;if(round[0]>=5){dialog.dismiss();showArcadeResult("Color Match complete",score[0],5,"Color Match",3);}else show[0].run();}); }
        };
        show[0].run(); dialog.show();
    }

    private void buildSettingsPage(LinearLayout root) {
        // Custom time signal
        sectionHeader(root, "CUSTOM TIME SIGNAL", "DAILY REMINDER");
        LinearLayout reminderCard = card();
        signalStatus = text("No daily signal scheduled", 15, WHITE, true);
        reminderCard.addView(signalStatus);
        TextView reminderHelp = text("Choose a time for a reminder with sound and vibration. Android may delay it when exact-alarm access is unavailable.", 12, MUTED, false);
        LinearLayout.LayoutParams rhlp = fullWrap(); rhlp.topMargin = dp(7); reminderCard.addView(reminderHelp, rhlp);
        signalMessageInput = editText(ProtectionPrefs.prefs(this).getString(ProtectionPrefs.KEY_REMINDER_MESSAGE, "Pause. Reset. Return to what matters."), "Reminder message");
        LinearLayout.LayoutParams smlp = fullWidth(); smlp.height = dp(62); smlp.topMargin = dp(12); reminderCard.addView(signalMessageInput, smlp);
        Button setSignal = button("SET CUSTOM TIME SIGNAL", AMBER);
        LinearLayout.LayoutParams sslp = fullWidth(); sslp.topMargin = dp(10); reminderCard.addView(setSignal, sslp);
        setSignal.setOnClickListener(v -> chooseReminderTime());
        Button disableSignal = smallButton("TURN OFF DAILY SIGNAL", PANEL_ALT);
        LinearLayout.LayoutParams dslp = fullWidth(); dslp.topMargin = dp(7); reminderCard.addView(disableSignal, dslp);
        disableSignal.setOnClickListener(v -> {
            ReminderScheduler.cancel(this);
            refreshStatuses();
            toast("Daily signal turned off");
        });
        root.addView(reminderCard);
        animateEntrance(reminderCard, 340);

        // Permissions and setup
        sectionHeader(root, "PERMISSIONS", "YOU STAY IN CONTROL");
        LinearLayout permCard = card();
        accessibilityStatus = text("Accessibility: checking…", 13, WHITE, true);
        permCard.addView(accessibilityStatus);
        Button accessibilityButton = button("OPEN ACCESSIBILITY SETTINGS", PANEL_ALT);
        LinearLayout.LayoutParams aclp = fullWidth(); aclp.topMargin = dp(10); permCard.addView(accessibilityButton, aclp);
        accessibilityButton.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        adminStatus = text("Device Admin: optional", 13, MUTED, true);
        LinearLayout.LayoutParams adlp = fullWrap(); adlp.topMargin = dp(17); permCard.addView(adminStatus, adlp);
        Button adminButton = button("ENABLE OPTIONAL DEVICE ADMIN", PANEL_ALT);
        LinearLayout.LayoutParams adbp = fullWidth(); adbp.topMargin = dp(9); permCard.addView(adminButton, adbp);
        adminButton.setOnClickListener(v -> requestDeviceAdmin());
        TextView adminNote = text("Device Admin may add a removal step, but a normal app cannot make itself undeletable. You can always revoke permissions and remove the app in Android Settings.", 11, MUTED, false);
        LinearLayout.LayoutParams anlp = fullWrap(); anlp.topMargin = dp(9); permCard.addView(adminNote, anlp);
        root.addView(permCard);
        animateEntrance(permCard, 410);


        sectionHeader(root, "PRIVACY & CONTROL", "CLEAR AND TRANSPARENT");
        LinearLayout privacy = card();
        privacy.addView(text("Your settings and progress are stored locally by this app. Protection tools use only the Android permissions you choose to enable.", 12, MUTED, false));
        TextView recovery = text("Android Settings always remains the place to revoke permissions, stop services or uninstall VYRA.", 11, MUTED, false);
        LinearLayout.LayoutParams rp = fullWrap(); rp.topMargin = dp(10); privacy.addView(recovery, rp);
        root.addView(privacy);
    }

    private void buildAboutAppCard(LinearLayout root) {
        sectionHeader(root, "ABOUT THIS APP", "A PROJECT BUILT AROUND FOCUS");
        LinearLayout appCard = card();
        appCard.addView(text("VYRA", 19, WHITE, true));
        TextView tag = text("Stay Pure. Make room for what matters.", 12, TEAL, true);
        LinearLayout.LayoutParams tp = fullWrap(); tp.topMargin = dp(5); appCard.addView(tag, tp);
        TextView body = text("VYRA brings together timed focus, a long-term journey counter, selected-app restrictions, local page-text checks, optional user-selected image scans, reminders, progress tracking, offline games and a custom block screen.", 12, MUTED, false);
        body.setLineSpacing(dp(3), 1.04f); LinearLayout.LayoutParams bp = fullWrap(); bp.topMargin = dp(12); appCard.addView(body, bp);
        TextView limitation = text("Detection is best-effort and depends on Android permissions and supported interfaces. VYRA Offline Guide uses local rules, not a generative AI model. No app can guarantee detection of every image, video or website.", 10, MUTED, false);
        LinearLayout.LayoutParams lp = fullWrap(); lp.topMargin = dp(10); appCard.addView(limitation, lp);
        root.addView(appCard);
    }

    private LinearLayout.LayoutParams fullWidthHeight(int height) {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height);
    }


    private void addCreatorProfile(LinearLayout root) {
        sectionHeader(root, "ABOUT THE CREATOR", "THE PERSON BEHIND VYRA");
        LinearLayout profile = card();

        LinearLayout hero = new LinearLayout(this);
        hero.setGravity(Gravity.CENTER_VERTICAL);
        hero.setPadding(dp(13), dp(13), dp(13), dp(13));
        hero.setBackground(gradient(new int[]{Color.rgb(15, 40, 59), Color.rgb(32, 26, 68), Color.rgb(22, 20, 43)}, 20, OUTLINE));

        ImageView portrait = new ImageView(this);
        portrait.setImageResource(R.drawable.profile_shafi);
        portrait.setScaleType(ImageView.ScaleType.CENTER_CROP);
        portrait.setBackground(round(PANEL, 18, Color.rgb(43, 61, 91)));
        portrait.setClipToOutline(true);
        portrait.setContentDescription("Profile photograph of Shafiullah Ali");
        portrait.setElevation(dp(3));
        LinearLayout.LayoutParams portraitLp = new LinearLayout.LayoutParams(dp(104), dp(130));
        portraitLp.rightMargin = dp(13);
        hero.addView(portrait, portraitLp);

        LinearLayout identity = new LinearLayout(this);
        identity.setOrientation(LinearLayout.VERTICAL);
        identity.addView(text("PERSONAL PROFILE", 9, TEAL, true));
        TextView displayName = text("Shafiullah Ali", 21, WHITE, true);
        displayName.setTypeface(Typeface.create("serif", Typeface.BOLD));
        LinearLayout.LayoutParams nlp = fullWrap(); nlp.topMargin = dp(5);
        identity.addView(displayName, nlp);
        TextView role = text("Student  •  Technology enthusiast  •  Builder", 11, MUTED, true);
        LinearLayout.LayoutParams rlp = fullWrap(); rlp.topMargin = dp(6);
        identity.addView(role, rlp);
        TextView tagline = text("Curious by nature. Focused on building useful things.", 11, MUTED, false);
        tagline.setLineSpacing(dp(2), 1.04f);
        LinearLayout.LayoutParams tlp = fullWrap(); tlp.topMargin = dp(8);
        identity.addView(tagline, tlp);
        hero.addView(identity, new LinearLayout.LayoutParams(0, -2, 1f));
        profile.addView(hero);

        TextView introHeading = text("A LITTLE INTRODUCTION", 10, TEAL, true);
        introHeading.setLetterSpacing(0.10f);
        LinearLayout.LayoutParams ihp = fullWrap(); ihp.topMargin = dp(18);
        profile.addView(introHeading, ihp);
        TextView introBody = text(
                "I'm a student who enjoys exploring technology, learning how digital products work, and turning ideas into practical projects. My interests include software development, artificial intelligence, mobile apps, cybersecurity, automation, design and entrepreneurship. I like learning by building, testing ideas, improving the details and understanding how things work behind the scenes.",
                13, MUTED, false);
        introBody.setLineSpacing(dp(4), 1.06f);
        LinearLayout.LayoutParams ibp = fullWrap(); ibp.topMargin = dp(7);
        profile.addView(introBody, ibp);

        addProfileBlock(profile, "EDUCATION & LEARNING",
                "Currently studying the ICS track, with Computer Science, Mathematics and Statistics. I use my studies as a foundation for stronger problem-solving, logical thinking and technical skills.");
        addProfileBlock(profile, "TECHNOLOGY INTERESTS",
                "Android app development • Python programming • AI and machine learning • Cybersecurity and digital safety • Web technology • Automation • User-interface and product design.");
        addProfileBlock(profile, "PROJECTS & CREATIVE WORK",
                "VYRA — a personal focus and digital-wellbeing app concept.\nASL Group — developing business and technology ideas under the ASL name.\nInstaFlora — creative work around floral branding, event presentation and digital promotion.");
        addProfileBlock(profile, "SKILLS I'M DEVELOPING",
                "Programming fundamentals, technical problem-solving, product planning, interface design, communication, leadership and organised project work. I treat these as skills to keep improving, not as finished achievements.");
        addProfileBlock(profile, "MY APPROACH",
                "I value consistency, curiosity, discipline and practical learning. I prefer building a working version, learning from what does not work, and refining it step by step rather than relying only on big claims.");
        addProfileBlock(profile, "FUTURE DIRECTION",
                "My goal is to keep learning, create useful technology products, develop meaningful ventures and build a strong foundation for long-term work. The focus is steady progress, useful skills and projects that solve real problems.");

        TextView interestsTitle = text("WHAT I'M INTO", 10, VIOLET, true);
        interestsTitle.setLetterSpacing(0.10f);
        LinearLayout.LayoutParams itp = fullWrap(); itp.topMargin = dp(17);
        profile.addView(interestsTitle, itp);
        LinearLayout tags = new LinearLayout(this);
        tags.setOrientation(LinearLayout.HORIZONTAL);
        tags.setGravity(Gravity.CENTER_VERTICAL);
        String[] tagsText = {"TECH & AI", "BUILDING", "DESIGN", "LEARNING"};
        int[] tagColors = {TEAL, VIOLET, AMBER, TEAL};
        for (int i = 0; i < tagsText.length; i++) {
            TextView chip = text(tagsText[i], 8, tagColors[i], true);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(8), dp(8), dp(8), dp(8));
            chip.setBackground(round(i == 1 ? Color.rgb(42, 34, 68) : (i == 2 ? Color.rgb(61, 49, 30) : Color.rgb(18, 47, 58)), 30, OUTLINE));
            LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(0, dp(34), 1f);
            chipLp.rightMargin = dp(5);
            tags.addView(chip, chipLp);
        }
        LinearLayout.LayoutParams tagsLp = fullWidth(); tagsLp.topMargin = dp(9);
        profile.addView(tags, tagsLp);

        TextView contactTitle = text("LET'S CONNECT", 10, TEAL, true);
        contactTitle.setLetterSpacing(0.10f);
        LinearLayout.LayoutParams ctp = fullWrap(); ctp.topMargin = dp(19);
        profile.addView(contactTitle, ctp);
        TextView handle = text("Instagram  @shafi.viii_", 14, WHITE, true);
        LinearLayout.LayoutParams hlp = fullWrap(); hlp.topMargin = dp(6);
        profile.addView(handle, hlp);
        TextView contactNote = text("For updates, creative work and project-related contact.", 11, MUTED, false);
        LinearLayout.LayoutParams cnlp = fullWrap(); cnlp.topMargin = dp(4);
        profile.addView(contactNote, cnlp);
        LinearLayout contactButtons = new LinearLayout(this);
        contactButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button openInstagram = button("OPEN INSTAGRAM", TEAL);
        Button copyHandle = button("COPY HANDLE", PANEL_ALT);
        LinearLayout.LayoutParams openLp = new LinearLayout.LayoutParams(0, dp(46), 1f); openLp.rightMargin = dp(5);
        LinearLayout.LayoutParams copyLp = new LinearLayout.LayoutParams(0, dp(46), 1f); copyLp.leftMargin = dp(5);
        contactButtons.addView(openInstagram, openLp);
        contactButtons.addView(copyHandle, copyLp);
        LinearLayout.LayoutParams contactLp = fullWidth(); contactLp.topMargin = dp(11);
        profile.addView(contactButtons, contactLp);
        openInstagram.setOnClickListener(v -> openCreatorInstagram());
        copyHandle.setOnClickListener(v -> {
            android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (clipboard != null) {
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Instagram", "@shafi.viii_"));
                toast("Instagram handle copied");
            }
        });

        Button shareProfile = smallButton("SHARE CREATOR PROFILE", PANEL_ALT);
        LinearLayout.LayoutParams shareLp = fullWidth(); shareLp.topMargin = dp(7);
        profile.addView(shareProfile, shareLp);
        shareProfile.setOnClickListener(v -> shareCreatorProfile());

        TextView privacy = text("Profile details are shown locally in this app. The Instagram button opens the public profile link; VYRA does not upload this photo.", 10, MUTED, false);
        LinearLayout.LayoutParams plp = fullWrap(); plp.topMargin = dp(13);
        profile.addView(privacy, plp);
        root.addView(profile);
        animateEntrance(profile, 120);
    }

    private void addProfileBlock(LinearLayout parent, String heading, String body) {
        TextView title = text(heading, 10, VIOLET, true);
        title.setLetterSpacing(0.09f);
        LinearLayout.LayoutParams titleLp = fullWrap(); titleLp.topMargin = dp(15);
        parent.addView(title, titleLp);
        TextView detail = text(body, 12, MUTED, false);
        detail.setLineSpacing(dp(3), 1.04f);
        LinearLayout.LayoutParams detailLp = fullWrap(); detailLp.topMargin = dp(5);
        parent.addView(detail, detailLp);
    }

    private void openCreatorInstagram() {
        Uri instagram = Uri.parse("https://www.instagram.com/shafi.viii_/");
        Intent intent = new Intent(Intent.ACTION_VIEW, instagram);
        try {
            startActivity(intent);
        } catch (Exception ex) {
            toast("Could not open Instagram on this device");
        }
    }

    private void shareCreatorProfile() {
        String message = "Shafiullah Ali\nStudent • Technology enthusiast • Builder\nInterested in software development, AI, Android apps, cybersecurity, automation and entrepreneurship.\nInstagram: https://www.instagram.com/shafi.viii_/";
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_SUBJECT, "About Shafiullah Ali");
        share.putExtra(Intent.EXTRA_TEXT, message);
        startActivity(Intent.createChooser(share, "Share creator profile"));
    }

    private void sectionHeader(LinearLayout root, String title, String caption) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        final String[] glyphs = {"✦", "◈", "⌁", "✧", "◎", "⌘", "◇", "✺", "◉", "✳"};
        final int[][] tints = {
                {Color.rgb(19, 54, 61), Color.rgb(17, 37, 54)},
                {Color.rgb(42, 34, 68), Color.rgb(26, 26, 54)},
                {Color.rgb(61, 49, 30), Color.rgb(48, 39, 29)},
                {Color.rgb(23, 45, 67), Color.rgb(21, 31, 52)}
        };
        int index = sectionIndex++;
        TextView emblem = text(glyphs[index % glyphs.length], 16, index % 3 == 1 ? VIOLET : TEAL, true);
        emblem.setGravity(Gravity.CENTER);
        emblem.setBackground(gradient(tints[index % tints.length], 11, OUTLINE));
        LinearLayout.LayoutParams emblemLp = new LinearLayout.LayoutParams(dp(32), dp(32));
        emblemLp.rightMargin = dp(10);
        row.addView(emblem, emblemLp);
        emblem.setScaleX(0.78f); emblem.setScaleY(0.78f); emblem.setRotation(-14f);
        emblem.animate().scaleX(1f).scaleY(1f).rotation(0f).setStartDelay(Math.min(180, index * 12L))
                .setDuration(420).setInterpolator(new android.view.animation.OvershootInterpolator(1.25f)).start();

        TextView left = text(title, 12, WHITE, true);
        left.setLetterSpacing(0.09f);
        left.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView right = text(caption, 9, TEAL, true);
        right.setLetterSpacing(0.10f);
        row.addView(right);
        LinearLayout.LayoutParams lp = fullWrap(); lp.topMargin = dp(23); lp.bottomMargin = dp(10);
        root.addView(row, lp);
    }

    private void addStat(LinearLayout row, String label, String value, int accent) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setPadding(dp(12), dp(13), dp(9), dp(13));
        tile.setBackground(round(PANEL, 15, OUTLINE));
        tile.addView(text(label, 9, MUTED, true));
        TextView v = text(value, 14, accent, true);
        LinearLayout.LayoutParams lp = fullWrap(); lp.topMargin = dp(6); tile.addView(v, lp);
        LinearLayout.LayoutParams tileLp = new LinearLayout.LayoutParams(0, dp(74), 1f);
        tileLp.rightMargin = dp(5); tileLp.leftMargin = dp(5); row.addView(tile, tileLp);
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(17), dp(17), dp(17), dp(17));
        box.setBackground(round(PANEL, 20, OUTLINE));
        box.setElevation(dp(3));
        box.setTranslationZ(dp(0));
        if (Build.VERSION.SDK_INT >= 21) box.setClipToOutline(false);
        return box;
    }

    private void addDuration(LinearLayout row, String label, int minutes, int ignored) {
        Button b = smallButton(label, PANEL_ALT);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f);
        lp.rightMargin = dp(5);
        row.addView(b, lp);
        b.setOnClickListener(v -> {
            selectedDurationMs = minutes * 60_000L;
            selectedDurationLabel = label.toLowerCase(Locale.ROOT);
            toast(label + " selected");
        });
    }

    private void chooseCustomDuration() {
        new TimePickerDialog(this, (view, hour, minute) -> {
            long mins = hour * 60L + minute;
            if (mins < 1) mins = 1;
            selectedDurationMs = mins * 60_000L;
            selectedDurationLabel = String.format(Locale.ROOT, "%dh %02dm", hour, minute);
            toast("Custom duration: " + selectedDurationLabel);
        }, 0, 45, true).show();
    }

    private void startFocus() {
        if (ProtectionPrefs.isJourneyActive(this)) {
            toast("Your long-term Focus Journey is already active.");
            return;
        }
        if (ProtectionPrefs.isFocusActive(this)) {
            toast("Your focus session is already running. The countdown cannot be reset mid-session.");
            return;
        }
        Set<String> selected = ProtectionPrefs.blockedPackages(this);
        long until = System.currentTimeMillis() + selectedDurationMs;
        ProtectionPrefs.prefs(this).edit()
                .putBoolean(ProtectionPrefs.KEY_STRICT_MODE, strictModeCheck != null && strictModeCheck.isChecked())
                .putLong(ProtectionPrefs.KEY_FOCUS_DURATION, selectedDurationMs)
                .putLong(ProtectionPrefs.KEY_FOCUS_UNTIL, until).apply();
        hideKeyboard(getCurrentFocus());
        refreshStatuses();
        if (!isAccessibilityEnabled()) {
            new AlertDialog.Builder(this)
                    .setTitle("One setup step remains")
                    .setMessage("The timer is running, but app blocking needs VYRA Protection enabled in Android Accessibility settings.")
                    .setNegativeButton("Later", null)
                    .setPositiveButton("Open settings", (d, w) -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                    .show();
        } else if (selected.isEmpty()) toast("Focus timer started. Choose apps to enable app blocking.");
        else toast("Focus started • " + selectedDurationLabel + " • " + selected.size() + " apps protected");
    }

    private void toggleLongTermJourney() {
        if (ProtectionPrefs.isJourneyActive(this)) {
            confirmEndFocus();
            return;
        }
        if (ProtectionPrefs.isFocusActive(this)) {
            toast("Finish or end the timed session before starting a long-term journey.");
            return;
        }
        long now = System.currentTimeMillis();
        boolean strict = strictModeCheck != null && strictModeCheck.isChecked();
        ProtectionPrefs.prefs(this).edit()
                .putBoolean(ProtectionPrefs.KEY_STRICT_MODE, strict)
                .putBoolean(ProtectionPrefs.KEY_FOCUS_JOURNEY_ACTIVE, true)
                .putLong(ProtectionPrefs.KEY_FOCUS_JOURNEY_STARTED_AT, now)
                .apply();
        refreshStatuses();
        if (!isAccessibilityEnabled()) {
            new AlertDialog.Builder(this)
                    .setTitle("Enable app protection")
                    .setMessage("Your journey timer has started. Selected-app blocking works only after you enable VYRA Protection in Android Accessibility settings.")
                    .setNegativeButton("Later", null)
                    .setPositiveButton("Open settings", (d, w) -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                    .show();
        } else if (ProtectionPrefs.blockedPackages(this).isEmpty()) {
            toast("Journey started. Choose apps to protect for enforcement.");
        } else {
            toast("Long-term Focus Journey started.");
        }
    }

    private void confirmEndFocus() {
        if (!ProtectionPrefs.isFocusActive(this)) {
            toast("No active focus session");
            return;
        }
        if (!ProtectionPrefs.isStrictMode(this)) {
            confirmEndFocusNow();
            return;
        }
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Strict Mode is active")
                .setMessage("To end early, pause for 30 seconds and make a deliberate choice. Your timer keeps running unless you confirm.")
                .setNegativeButton("Keep focusing", null)
                .setPositiveButton("Wait 30 seconds", null)
                .create();
        dialog.setOnShowListener(ignored -> {
            Button positive = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            positive.setEnabled(false);
            final long started = android.os.SystemClock.elapsedRealtime();
            final Runnable[] tick = new Runnable[1];
            tick[0] = () -> {
                if (!dialog.isShowing()) return;
                long left = 30_000L - (android.os.SystemClock.elapsedRealtime() - started);
                if (left <= 0) {
                    positive.setText("End session");
                    positive.setEnabled(true);
                } else {
                    positive.setText("Wait " + ((left + 999L) / 1000L) + "s");
                    handler.postDelayed(tick[0], 250L);
                }
            };
            positive.setOnClickListener(v -> {
                if (android.os.SystemClock.elapsedRealtime() - started >= 30_000L) {
                    dialog.dismiss();
                    confirmEndFocusNow();
                }
            });
            tick[0].run();
        });
        dialog.show();
    }

    private void confirmEndFocusNow() {
        new AlertDialog.Builder(this)
                .setTitle("End focus session?")
                .setMessage(ProtectionPrefs.isJourneyActive(this)
                        ? "This ends the long-term journey and restores access to your selected apps. The elapsed journey time will be saved."
                        : "This restores access to your selected apps. A timed-session reward is awarded only when the timer reaches zero.")
                .setNegativeButton("Keep focusing", null)
                .setPositiveButton("End session", (dialog, which) -> {
                    android.content.SharedPreferences prefs = ProtectionPrefs.prefs(this);
                    android.content.SharedPreferences.Editor edit = prefs.edit().putLong(ProtectionPrefs.KEY_FOCUS_UNTIL, 0L);
                    if (ProtectionPrefs.isJourneyActive(this)) {
                        long started = prefs.getLong(ProtectionPrefs.KEY_FOCUS_JOURNEY_STARTED_AT, System.currentTimeMillis());
                        edit.putBoolean(ProtectionPrefs.KEY_FOCUS_JOURNEY_ACTIVE, false)
                                .putLong(ProtectionPrefs.KEY_FOCUS_JOURNEY_LAST_MS, Math.max(0L, System.currentTimeMillis() - started));
                    }
                    edit.apply();
                    refreshStatuses();
                    toast("Focus protection ended");
                }).show();
    }

    private void showAppPicker() {
        if (ProtectionPrefs.isFocusActive(this)) {
            toast("App restrictions are fixed until this session ends.");
            return;
        }
        List<ResolveInfo> apps = getLaunchableApps();
        if (apps.isEmpty()) {
            toast("No launchable apps were found");
            return;
        }
        Set<String> current = ProtectionPrefs.blockedPackages(this);
        String[] labels = new String[apps.size()];
        boolean[] checked = new boolean[apps.size()];
        Set<String> chosen = new HashSet<>(current);
        for (int i = 0; i < apps.size(); i++) {
            ResolveInfo info = apps.get(i);
            labels[i] = String.valueOf(info.loadLabel(getPackageManager()));
            checked[i] = current.contains(info.activityInfo.packageName.toLowerCase(Locale.ROOT));
        }
        new AlertDialog.Builder(this)
                .setTitle("Choose apps to block")
                .setMultiChoiceItems(labels, checked, (dialog, which, isChecked) -> {
                    String packageName = apps.get(which).activityInfo.packageName.toLowerCase(Locale.ROOT);
                    if (isChecked) chosen.add(packageName); else chosen.remove(packageName);
                })
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save selection", (dialog, which) -> {
                    ProtectionPrefs.saveBlockedPackages(this, chosen);
                    refreshStatuses();
                    toast(chosen.size() + " apps selected");
                }).show();
    }

    private List<ResolveInfo> getLaunchableApps() {
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = getPackageManager().queryIntentActivities(intent, 0);
        java.util.LinkedHashMap<String, ResolveInfo> byPackage = new java.util.LinkedHashMap<>();
        for (ResolveInfo info : found) {
            if (info.activityInfo == null) continue;
            String pkg = info.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || pkg.equals("com.android.settings")) continue;
            byPackage.putIfAbsent(pkg, info);
        }
        List<ResolveInfo> result = new ArrayList<>(byPackage.values());
        result.sort((a, b) -> String.valueOf(a.loadLabel(getPackageManager())).compareToIgnoreCase(String.valueOf(b.loadLabel(getPackageManager()))));
        return result;
    }

    private void installModel() {
        if (ModelManager.isReady(this)) {
            toast("AI model is already installed");
            refreshStatuses();
            return;
        }
        aiProgress.setVisibility(View.VISIBLE);
        aiProgress.setProgress(0);
        aiProgressText.setText("Downloading the on-device model over HTTPS…");
        aiStatus.setText("Installing AI model…");
        ModelManager.download(this, new ModelManager.Callback() {
            @Override public void onProgress(int percent) {
                runOnUiThread(() -> {
                    aiProgress.setProgress(percent);
                    aiProgressText.setText("Downloading model: " + percent + "%");
                });
            }
            @Override public void onComplete(boolean success, String message) {
                runOnUiThread(() -> {
                    aiProgress.setVisibility(View.GONE);
                    aiProgressText.setText(message);
                    refreshStatuses();
                    toast(message);
                });
            }
        });
    }

    private void toggleVisualProtection() {
        boolean active = ProtectionPrefs.prefs(this).getBoolean(ProtectionPrefs.KEY_VISUAL_SCAN_ACTIVE, false);
        if (active) {
            Intent stop = new Intent(this, VisualScreenProtectionService.class).setAction(VisualScreenProtectionService.ACTION_STOP);
            startService(stop);
            toast("Stopping live visual protection…");
            return;
        }
        if (!ModelManager.isReady(this)) {
            toast("Install the on-device AI model first.");
            installModel();
            return;
        }
        if (!ProtectionPrefs.isAccessibilityEnabled(this)) {
            new AlertDialog.Builder(this)
                    .setTitle("Enable VYRA accessibility")
                    .setMessage("VYRA needs its Accessibility service to leave the current app and show the block screen when a visual detection is triggered. Enable VYRA in Android Accessibility settings, then return here.")
                    .setNegativeButton("CANCEL", null)
                    .setPositiveButton("OPEN SETTINGS", (dialog, which) -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                    .show();
            return;
        }
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        if (manager == null) { toast("Android screen-capture service is unavailable on this device."); return; }
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_VISUAL_CAPTURE);
    }

    private void openImagePicker() {
        if (!ModelManager.isReady(this)) {
            toast("Install the AI model first");
            return;
        }
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("image/*");
        startActivityForResult(pick, REQUEST_IMAGE);
    }

    private void scanPickedImage(Uri uri) {
        aiStatus.setText("Checking image on this device…");
        scanExecutor.execute(() -> {
            Bitmap bitmap = null;
            try {
                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                try (InputStream boundsInput = getContentResolver().openInputStream(uri)) {
                    BitmapFactory.decodeStream(boundsInput, null, bounds);
                }
                int longest = Math.max(bounds.outWidth, bounds.outHeight);
                int sample = 1;
                while (longest / sample > 1600) sample *= 2;
                BitmapFactory.Options decodeOptions = new BitmapFactory.Options();
                decodeOptions.inSampleSize = sample;
                try (InputStream input = getContentResolver().openInputStream(uri)) {
                    bitmap = BitmapFactory.decodeStream(input, null, decodeOptions);
                }
                if (bitmap == null) throw new IllegalStateException("Could not read selected image");
                ImageSafetyClassifier.Result result;
                try (ImageSafetyClassifier classifier = new ImageSafetyClassifier(ModelManager.modelFile(this))) {
                    result = classifier.classify(bitmap);
                }
                final ImageSafetyClassifier.Result finalResult = result;
                runOnUiThread(() -> {
                    if (finalResult.flagged) {
                        aiStatus.setText("Potentially unsafe visual content detected");
                        new AlertDialog.Builder(this).setTitle("VYRA scan")
                                .setMessage("This image crossed the local safety threshold. It was checked on-device and has not been uploaded or saved by VYRA.")
                                .setPositiveButton("Done", null).show();
                    } else {
                        aiStatus.setText("No high-confidence match found");
                        toast("No high-confidence match. This is not a guarantee that the image is safe.");
                    }
                });
            } catch (Exception ex) {
                runOnUiThread(() -> {
                    aiStatus.setText("Image scan unavailable");
                    toast(ex.getMessage() == null ? "Image scan failed" : ex.getMessage());
                });
            } finally {
                if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            }
        });
    }

    private void chooseReminderTime() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        }
        int hour = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_REMINDER_HOUR, 20);
        int minute = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_REMINDER_MINUTE, 0);
        new TimePickerDialog(this, (view, h, m) -> {
            ProtectionPrefs.prefs(this).edit().putString(ProtectionPrefs.KEY_REMINDER_MESSAGE,
                    signalMessageInput.getText().toString().trim().isEmpty()
                            ? "Pause. Reset. Return to what matters." : signalMessageInput.getText().toString().trim()).apply();
            ReminderScheduler.schedule(this, h, m);
            refreshStatuses();
            toast(String.format(Locale.ROOT, "Daily signal set for %02d:%02d", h, m));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                android.app.AlarmManager alarm = (android.app.AlarmManager) getSystemService(ALARM_SERVICE);
                if (!alarm.canScheduleExactAlarms()) {
                    new AlertDialog.Builder(this).setTitle("Allow precise reminders?")
                            .setMessage("You can grant VYRA Alarms & reminders access for closer timing. Without it, Android may delay the notification.")
                            .setNegativeButton("Use flexible timing", null)
                            .setPositiveButton("Open settings", (d, w) -> {
                                try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)); } catch (Exception ignored) { }
                            }).show();
                }
            }
        }, hour, minute, true).show();
    }

    private void requestDeviceAdmin() {
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        ComponentName admin = new ComponentName(this, NexasDeviceAdminReceiver.class);
        if (dpm.isAdminActive(admin)) {
            toast("Device Admin is already enabled");
            return;
        }
        Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin);
        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Optional uninstall friction. This does not prevent the device owner from disabling the admin or uninstalling the app.");
        startActivityForResult(intent, REQUEST_ADMIN);
    }

    private void ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        }
    }

    private void updateJourneyLevel() {
        if (levelStatus == null || levelNextStatus == null || levelProgress == null) return;
        android.content.SharedPreferences prefs = ProtectionPrefs.prefs(this);
        long startMillis = prefs.getLong(ProtectionPrefs.KEY_FOCUS_JOURNEY_STARTED_AT, 0L);
        if (startMillis <= 0L) {
            levelStatus.setText("LEVEL 0  •  JOURNEY NOT STARTED");
            levelNextStatus.setText("Start a Long-term Journey to unlock your first milestone.");
            levelProgress.setProgress(0);
            return;
        }
        java.time.ZoneId zone = java.time.ZoneId.systemDefault();
        java.time.ZonedDateTime start = java.time.Instant.ofEpochMilli(startMillis).atZone(zone);
        boolean active = ProtectionPrefs.isJourneyActive(this);
        long savedDuration = active ? Math.max(0L, System.currentTimeMillis() - startMillis)
                : Math.max(0L, prefs.getLong(ProtectionPrefs.KEY_FOCUS_JOURNEY_LAST_MS, 0L));
        java.time.ZonedDateTime current = active
                ? java.time.ZonedDateTime.now(zone) : start.plusMillis(savedDuration);
        java.time.ZonedDateTime[] milestones = {
                start.plusDays(1), start.plusDays(7), start.plusMonths(1), start.plusMonths(3),
                start.plusMonths(6), start.plusYears(1), start.plusYears(2), start.plusYears(5), start.plusYears(10)
        };
        String[] milestoneNames = {"1 day", "7 days", "1 month", "3 months", "6 months", "1 year", "2 years", "5 years", "10 years"};
        int level = 0;
        while (level < milestones.length && !current.isBefore(milestones[level])) level++;
        int bestLevel = prefs.getInt(ProtectionPrefs.KEY_FOCUS_JOURNEY_BEST_LEVEL, 0);
        if (level > bestLevel) {
            bestLevel = level;
            prefs.edit().putInt(ProtectionPrefs.KEY_FOCUS_JOURNEY_BEST_LEVEL, bestLevel).apply();
        }
        levelStatus.setText(level == 0 ? "LEVEL 0  •  BUILD YOUR FIRST DAY" : "LEVEL " + level + "  •  MILESTONE REACHED");
        if (level >= milestones.length) {
            levelNextStatus.setText("All 9 milestones reached. Personal best: Level " + bestLevel + ". Keep going.");
            levelProgress.setProgress(100);
        } else {
            levelNextStatus.setText("Personal best: Level " + bestLevel + "  •  Next achievement: " + milestoneNames[level]);
            java.time.ZonedDateTime previous = level == 0 ? start : milestones[level - 1];
            long elapsed = java.time.Duration.between(previous, current).toMillis();
            long span = Math.max(1L, java.time.Duration.between(previous, milestones[level]).toMillis());
            long percent = Math.max(0L, Math.min(100L, elapsed * 100L / span));
            levelProgress.setProgress((int) percent);
        }
    }

    private String formatJourneyElapsed(long startedAt) {
        return formatJourneyElapsed(startedAt, System.currentTimeMillis());
    }

    private String formatJourneyElapsed(long startedAt, long endedAt) {
        java.time.ZoneId zone = java.time.ZoneId.systemDefault();
        java.time.LocalDateTime start = java.time.Instant.ofEpochMilli(startedAt).atZone(zone).toLocalDateTime();
        java.time.LocalDateTime now = java.time.Instant.ofEpochMilli(endedAt).atZone(zone).toLocalDateTime();
        if (now.isBefore(start)) return "0 years  ·  0 months  ·  0 days\nClock time moved before the saved start";
        java.time.Period period = java.time.Period.between(start.toLocalDate(), now.toLocalDate());
        java.time.LocalDateTime anchor = start.plusYears(period.getYears()).plusMonths(period.getMonths()).plusDays(period.getDays());
        if (anchor.isAfter(now)) {
            period = period.minusDays(1);
            anchor = start.plusYears(period.getYears()).plusMonths(period.getMonths()).plusDays(period.getDays());
        }
        long seconds = Math.max(0L, java.time.Duration.between(anchor, now).getSeconds());
        long hours = seconds / 3600L;
        long minutes = (seconds % 3600L) / 60L;
        long secs = seconds % 60L;
        return String.format(Locale.ROOT, "%d years  ·  %d months  ·  %d days\n%02d:%02d:%02d", period.getYears(), period.getMonths(), period.getDays(), hours, minutes, secs);
    }

    private boolean isAccessibilityEnabled() {
        return ProtectionPrefs.isAccessibilityEnabled(this);
    }

    private void refreshStatuses() {
        if (focusStatus == null) return;
        updateCompletedSessionReward();
        boolean focusOn = ProtectionPrefs.isFocusActive(this);
        long until = ProtectionPrefs.isJourneyActive(this) ? 0L : ProtectionPrefs.focusUntil(this);
        long totalDuration = ProtectionPrefs.prefs(this).getLong(ProtectionPrefs.KEY_FOCUS_DURATION, 45L * 60L * 1000L);
        if (countdownDial != null) countdownDial.setTimer(focusOn && !ProtectionPrefs.isJourneyActive(this) ? until : 0L, totalDuration);
        if (focusOn) {
            if (ProtectionPrefs.isJourneyActive(this)) {
                focusStatus.setText("LONG-TERM JOURNEY ACTIVE");
                if (focusSubtitle != null) focusSubtitle.setText("Your journey timer keeps running until you explicitly end it.");
            } else {
                long remaining = Math.max(0L, until - System.currentTimeMillis());
                long seconds = remaining / 1000L;
                focusStatus.setText(String.format(Locale.ROOT, "FOCUS ACTIVE  %02d:%02d:%02d", seconds / 3600, (seconds % 3600) / 60, seconds % 60));
                if (focusSubtitle != null) focusSubtitle.setText("Selected apps are being restricted until this timer reaches zero.");
            }
            if (startFocusButton != null) { startFocusButton.setText("FOCUS SESSION ACTIVE"); startFocusButton.setEnabled(false); }
            if (strictModeCheck != null) strictModeCheck.setEnabled(false);
        } else {
            focusStatus.setText("Protection is ready");
            if (focusSubtitle != null) focusSubtitle.setText("Screen checks stay on this device. Enable only the permissions you want to use.");
            if (startFocusButton != null) { startFocusButton.setText("START FOCUS SESSION"); startFocusButton.setEnabled(true); }
            if (strictModeCheck != null) strictModeCheck.setEnabled(true);
        }
        boolean journeyActive = ProtectionPrefs.isJourneyActive(this);
        if (journeyStatus != null) journeyStatus.setText(journeyActive ? "LONG-TERM JOURNEY ACTIVE" : "Journey not started");
        if (journeyElapsed != null) {
            android.content.SharedPreferences journeyPrefs = ProtectionPrefs.prefs(this);
            long started = journeyPrefs.getLong(ProtectionPrefs.KEY_FOCUS_JOURNEY_STARTED_AT, 0L);
            if (started > 0L && journeyActive) {
                journeyElapsed.setText(formatJourneyElapsed(started));
            } else if (started > 0L) {
                long saved = Math.max(0L, journeyPrefs.getLong(ProtectionPrefs.KEY_FOCUS_JOURNEY_LAST_MS, 0L));
                journeyElapsed.setText("COMPLETED JOURNEY\n" + formatJourneyElapsed(started, started + saved));
            } else {
                journeyElapsed.setText("Start a journey to track years, months, days and time.");
            }
        }
        if (journeyButton != null) journeyButton.setText(journeyActive ? "END LONG-TERM JOURNEY" : "START LONG-TERM JOURNEY");
        updateJourneyLevel();

        boolean aiReady = ModelManager.isReady(this);
        if (aiStatus != null) {
            aiStatus.setText(aiReady ? "On-device AI model installed" : "AI model is not installed");
            aiStatus.setTextColor(aiReady ? TEAL : WHITE);
        }
        boolean visualActive = ProtectionPrefs.prefs(this).getBoolean(ProtectionPrefs.KEY_VISUAL_SCAN_ACTIVE, false);
        if (visualScanStatus != null) {
            visualScanStatus.setText(visualActive ? "LIVE IMAGE SCAN: ACTIVE" : "LIVE IMAGE SCAN: OFF");
            visualScanStatus.setTextColor(visualActive ? TEAL : AMBER);
        }
        if (visualScanButton != null) visualScanButton.setText(visualActive ? "STOP LIVE IMAGE PROTECTION" : "ENABLE LIVE IMAGE PROTECTION");
        Set<String> selected = ProtectionPrefs.blockedPackages(this);
        if (appSelectionStatus != null) appSelectionStatus.setText(selected.size() + " apps selected for Focus Mode");
        boolean accessibility = isAccessibilityEnabled();
        if (accessibilityStatus != null) {
            accessibilityStatus.setText("Accessibility: " + (accessibility ? "ENABLED" : "NOT ENABLED"));
            accessibilityStatus.setTextColor(accessibility ? TEAL : AMBER);
        }
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        boolean admin = dpm.isAdminActive(new ComponentName(this, NexasDeviceAdminReceiver.class));
        if (adminStatus != null) {
            adminStatus.setText("Device Admin: " + (admin ? "ENABLED" : "OPTIONAL / OFF"));
            adminStatus.setTextColor(admin ? TEAL : MUTED);
        }
        if (shieldPill != null) shieldPill.setText((focusOn || accessibility) ? "●  ACTIVE" : "●  READY");
        boolean reminder = ProtectionPrefs.prefs(this).getBoolean(ProtectionPrefs.KEY_REMINDER_ENABLED, false);
        if (signalStatus != null) {
            if (reminder) {
                int h = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_REMINDER_HOUR, 20);
                int m = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_REMINDER_MINUTE, 0);
                signalStatus.setText(String.format(Locale.ROOT, "Daily focus signal • %02d:%02d", h, m));
            } else signalStatus.setText("No daily signal scheduled");
        }
        if (streakStatus != null) {
            android.content.SharedPreferences journeyPrefs = ProtectionPrefs.prefs(this);
            long started = journeyPrefs.getLong(ProtectionPrefs.KEY_FOCUS_JOURNEY_STARTED_AT, 0L);
            boolean activeJourney = ProtectionPrefs.isJourneyActive(this);
            streakStatus.setText(activeJourney ? "FOCUS JOURNEY ACTIVE"
                    : (started > 0L ? "JOURNEY SAVED" : "JOURNEY NOT STARTED"));
        }
        if (pointsStatus != null) pointsStatus.setText(ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_FOCUS_POINTS, 0) + " pts");
        if (bestStreakStatus != null) {
            boolean activeJourney = ProtectionPrefs.isJourneyActive(this);
            boolean hasJourney = ProtectionPrefs.prefs(this).getLong(ProtectionPrefs.KEY_FOCUS_JOURNEY_STARTED_AT, 0L) > 0L;
            bestStreakStatus.setText(hasJourney ? "MILESTONES BELOW" : "START JOURNEY");
        }
        if (dailyGoalStatus != null && dailyGoalProgress != null) {
            int completed = getTodayFocusMinutes();
            int goal = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_DAILY_GOAL_MINUTES, 120);
            dailyGoalStatus.setText(completed + " / " + goal + " minutes today");
            dailyGoalProgress.setProgress(Math.min(100, Math.round((completed * 100f) / Math.max(1, goal))));
        }
        if (blockImageStatus != null) {
            String image = ProtectionPrefs.prefs(this).getString(ProtectionPrefs.KEY_BLOCK_SCREEN_IMAGE, "");
            blockImageStatus.setText(image == null || image.isEmpty() ? "No custom block-screen image selected" : "Custom block-screen image is ready");
        }
    }

    private void pickBlockScreenImage() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("image/*");
        startActivityForResult(pick, REQUEST_BLOCK_IMAGE);
    }

    private void updateCompletedSessionReward() {
        long focusUntil = ProtectionPrefs.prefs(this).getLong(ProtectionPrefs.KEY_FOCUS_UNTIL, 0L);
        long lastRewardedUntil = ProtectionPrefs.prefs(this).getLong(ProtectionPrefs.KEY_LAST_COMPLETED_UNTIL, 0L);
        if (focusUntil > 0L && focusUntil <= System.currentTimeMillis() && focusUntil != lastRewardedUntil) {
            java.util.Calendar cal = java.util.Calendar.getInstance();
            int today = cal.get(java.util.Calendar.YEAR) * 1000 + cal.get(java.util.Calendar.DAY_OF_YEAR);
            int lastDay = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_LAST_COMPLETED_DAY, 0);
            int streak = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_STREAK_COUNT, 0);
            int best = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_BEST_STREAK, 0);
            // Calendar-aware previous-day comparison handles year boundaries.
            java.util.Calendar prev = java.util.Calendar.getInstance(); prev.add(java.util.Calendar.DAY_OF_YEAR, -1);
            int previousDay = prev.get(java.util.Calendar.YEAR) * 1000 + prev.get(java.util.Calendar.DAY_OF_YEAR);
            if (lastDay == today) { /* A second completed session today keeps the same streak. */ }
            else if (lastDay == previousDay) streak++;
            else streak = 1;
            best = Math.max(best, streak);
            int points = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_FOCUS_POINTS, 0) + 25;
            int todayMinutes = getTodayFocusMinutes();
            int sessionMinutes = (int) Math.max(1L, ProtectionPrefs.prefs(this).getLong(ProtectionPrefs.KEY_FOCUS_DURATION, 45L * 60L * 1000L) / 60_000L);
            ProtectionPrefs.prefs(this).edit()
                    .putInt(ProtectionPrefs.KEY_FOCUS_DAY_KEY, today)
                    .putInt(ProtectionPrefs.KEY_TODAY_FOCUS_MINUTES, todayMinutes + sessionMinutes)
                    .putInt(ProtectionPrefs.KEY_STREAK_COUNT, streak)
                    .putInt(ProtectionPrefs.KEY_BEST_STREAK, best)
                    .putInt(ProtectionPrefs.KEY_FOCUS_POINTS, points)
                    .putInt(ProtectionPrefs.KEY_LAST_COMPLETED_DAY, today)
                    .putLong(ProtectionPrefs.KEY_LAST_COMPLETED_UNTIL, focusUntil)
                    .putLong(ProtectionPrefs.KEY_FOCUS_UNTIL, 0L).apply();
            toast("Focus session complete • +25 points");
        }
    }

    private int getTodayFocusMinutes() {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        int today = cal.get(java.util.Calendar.YEAR) * 1000 + cal.get(java.util.Calendar.DAY_OF_YEAR);
        int savedDay = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_FOCUS_DAY_KEY, today);
        if (savedDay != today) return 0;
        return ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_TODAY_FOCUS_MINUTES, 0);
    }

    private void startBreathingReset() {
        final TextView prompt = text("Breathe in slowly…", 22, WHITE, true);
        prompt.setGravity(Gravity.CENTER);
        LinearLayout layout = new LinearLayout(this); layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(18), dp(24), dp(18), dp(24)); layout.setBackground(round(PANEL, 18, OUTLINE));
        layout.addView(prompt, fullWidth());
        TextView details = text("Follow four gentle cycles. This is a short reset, not a performance test.", 12, MUTED, false);
        LinearLayout.LayoutParams det = fullWrap(); det.topMargin = dp(12); layout.addView(details, det);
        final AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Breathing reset").setView(layout).setNegativeButton("Close", null).create();
        dialog.setOnShowListener(d -> {
            final int[] phase = {0};
            final Runnable[] cycle = new Runnable[1];
            cycle[0] = () -> {
                if (!dialog.isShowing()) return;
                int n = phase[0]++;
                if (n >= 8) { prompt.setText("Reset complete"); details.setText("Take the next step with intention."); return; }
                prompt.setText((n % 2 == 0) ? "Breathe in • 4" : "Breathe out • 6");
                prompt.animate().alpha(0.65f).setDuration(450).withEndAction(() -> prompt.animate().alpha(1f).setDuration(450).start()).start();
                handler.postDelayed(cycle[0], n % 2 == 0 ? 4000L : 6000L);
            };
            cycle[0].run();
        });
        dialog.show();
    }

    private void startPatternGame() {
        final String[] patterns = {"4 1 7", "2 8 3 6", "9 5 1 4 7"};
        final int[] round = {0};
        final TextView patternView = text(patterns[0], 28, TEAL, true); patternView.setGravity(Gravity.CENTER);
        final EditText answer = editText("", "Type the pattern you remember");
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18), dp(18), dp(18), dp(18));
        box.addView(text("Memorise the sequence, then enter it when hidden.", 12, MUTED, false));
        LinearLayout.LayoutParams pp = fullWidth(); pp.height = dp(58); pp.topMargin = dp(12); box.addView(patternView, pp);
        LinearLayout.LayoutParams ap = fullWidth(); ap.height = dp(58); ap.topMargin = dp(10); box.addView(answer, ap);
        final AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Pattern memory").setView(box)
                .setNegativeButton("Close", null).setPositiveButton("Check", null).create();
        dialog.setOnShowListener(d -> {
            Button check = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            patternView.postDelayed(() -> { if (dialog.isShowing()) patternView.setText("••••  HIDDEN  ••••"); }, 2200L);
            check.setOnClickListener(v -> {
                if (answer.getText().toString().trim().replaceAll("\\s+", " ").equals(patterns[round[0]])) {
                    round[0]++;
                    if (round[0] >= patterns.length) {
                        recordArcadeCompletion("Pattern Memory");
                        int points = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_FOCUS_POINTS, 0) + 5;
                        ProtectionPrefs.prefs(this).edit().putInt(ProtectionPrefs.KEY_FOCUS_POINTS, points).apply();
                        toast("Pattern game complete • +5 points"); dialog.dismiss(); refreshStatuses();
                    } else {
                        patternView.setText(patterns[round[0]]); answer.setText("");
                        final int next = round[0];
                        patternView.postDelayed(() -> { if (dialog.isShowing() && round[0] == next) patternView.setText("••••  HIDDEN  ••••"); }, 2200L);
                    }
                } else { answer.setError("Not quite. Try again."); }
            });
        });
        dialog.show();
    }

    private final class CountdownDial extends View {
        private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint progress = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint haloPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tickPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint particlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint innerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF arcBounds = new RectF();
        private long endAt = 0L;
        private long duration = 45L * 60L * 1000L;
        private final int[] ringColors = new int[]{Color.rgb(20, 164, 139), Color.rgb(115, 101, 211), Color.rgb(20, 164, 139)};

        CountdownDial(Context context) {
            super(context);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            track.setStyle(Paint.Style.STROKE); track.setStrokeWidth(dp(10)); track.setStrokeCap(Paint.Cap.ROUND); track.setColor(Color.rgb(37, 53, 78));
            progress.setStyle(Paint.Style.STROKE); progress.setStrokeWidth(dp(11)); progress.setStrokeCap(Paint.Cap.ROUND);
            haloPaint.setStyle(Paint.Style.STROKE); haloPaint.setStrokeWidth(dp(19)); haloPaint.setColor(Color.argb(20, 20, 164, 139));
            tickPaint.setStrokeCap(Paint.Cap.ROUND); tickPaint.setStrokeWidth(dp(1));
            particlePaint.setStyle(Paint.Style.FILL);
            innerPaint.setStyle(Paint.Style.STROKE); innerPaint.setStrokeWidth(dp(1)); innerPaint.setColor(Color.rgb(37, 53, 78));
            textPaint.setColor(WHITE); textPaint.setTextAlign(Paint.Align.CENTER); textPaint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            labelPaint.setColor(MUTED); labelPaint.setTextAlign(Paint.Align.CENTER); labelPaint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        }

        void setTimer(long until, long total) {
            endAt = until; duration = Math.max(60_000L, total); invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float radius = Math.min(getWidth(), getHeight()) * 0.365f;
            long now = System.currentTimeMillis();
            boolean active = endAt > now;
            // The ring fills clockwise as the session progresses: empty at the start,
            // complete at zero remaining time. The digital clock remains readable in its centre.
            float remainingFraction = active ? Math.max(0f, Math.min(1f, (endAt - now) / (float) duration)) : 0f;
            float fraction = active ? 1f - remainingFraction : 0f;
            float pulse = 0.5f + 0.5f * (float)Math.sin(now / 720.0);

            // Soft ambient halo and layered guide rings create depth without bitmap assets.
            haloPaint.setColor(Color.argb(active ? (int)(18 + 12 * pulse) : 12, 20, 164, 139));
            canvas.drawCircle(cx, cy, radius + dp(7), haloPaint);
            track.setStrokeWidth(dp(10));
            canvas.drawCircle(cx, cy, radius, track);
            canvas.drawCircle(cx, cy, radius - dp(17), innerPaint);

            // Sixty precision marks; every fifth mark receives a stronger accent.
            for (int i = 0; i < 60; i++) {
                double a = Math.toRadians(i * 6d - 90d);
                boolean major = i % 5 == 0;
                float inner = radius + (major ? dp(9) : dp(11));
                float outer = radius + dp(major ? 17 : 14);
                float x1 = cx + (float)Math.cos(a) * inner;
                float y1 = cy + (float)Math.sin(a) * inner;
                float x2 = cx + (float)Math.cos(a) * outer;
                float y2 = cy + (float)Math.sin(a) * outer;
                tickPaint.setColor(major ? Color.rgb(100, 132, 163) : Color.rgb(51, 70, 98));
                tickPaint.setStrokeWidth(dp(major ? 1.7f : 0.8f));
                canvas.drawLine(x1, y1, x2, y2, tickPaint);
            }

            progress.setShader(new SweepGradient(cx, cy, ringColors, null));
            canvas.save(); canvas.rotate(-90f, cx, cy);
            if (active && fraction > 0.001f) {
                Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
                glow.setStyle(Paint.Style.STROKE); glow.setStrokeCap(Paint.Cap.ROUND);
                glow.setStrokeWidth(dp(17)); glow.setColor(Color.argb((int)(28 + 18 * pulse), 20, 164, 139));
                float sweep = 360f * fraction;
                canvas.drawArc(arcBoundsFor(cx, cy, radius), 0f, sweep, false, glow);
                canvas.drawArc(arcBoundsFor(cx, cy, radius), 0f, sweep, false, progress);
            }
            canvas.restore();
            progress.setShader(null);

            // Orbit particles drift smoothly and are redrawn with the once-per-second timer tick.
            if (active) {
                for (int i = 0; i < 18; i++) {
                    double a = Math.toRadians((i * 20d) + (now / 170.0));
                    float orbit = radius + dp(24) + (float)Math.sin(now / 460.0 + i) * dp(2);
                    float px = cx + (float)Math.cos(a) * orbit;
                    float py = cy + (float)Math.sin(a) * orbit;
                    int alpha = 35 + (int)(75 * (0.5 + 0.5 * Math.sin(now / 380.0 + i)));
                    particlePaint.setColor(Color.argb(alpha, 20, 164, 139));
                    canvas.drawCircle(px, py, dp((i % 3 == 0) ? 2.2f : 1.3f), particlePaint);
                }
                double angle = Math.toRadians(-90d + 360d * fraction);
                float dotX = cx + (float)Math.cos(angle) * radius;
                float dotY = cy + (float)Math.sin(angle) * radius;
                particlePaint.setColor(Color.argb(55, 20, 164, 139));
                canvas.drawCircle(dotX, dotY, dp(12 + 2 * pulse), particlePaint);
                particlePaint.setColor(Color.WHITE);
                canvas.drawCircle(dotX, dotY, dp(5.5f), particlePaint);
                particlePaint.setColor(TEAL);
                canvas.drawCircle(dotX, dotY, dp(3.2f), particlePaint);
            }

            String timeText;
            String label;
            if (active) {
                long secs = Math.max(0L, (endAt - now) / 1000L);
                timeText = secs >= 3600L ? String.format(Locale.ROOT, "%02d:%02d:%02d", secs/3600L, (secs%3600L)/60L, secs%60L)
                        : String.format(Locale.ROOT, "%02d:%02d", secs/60L, secs%60L);
                label = "TIME LEFT";
            } else { timeText = "READY"; label = "YOUR NEXT FOCUS SESSION"; }
            textPaint.setTextSize(dp(active ? 29 : 28));
            canvas.drawText(timeText, cx, cy + dp(5), textPaint);
            labelPaint.setTextSize(dp(9));
            canvas.drawText(label, cx, cy + dp(27), labelPaint);
            if (active) {
                labelPaint.setColor(TEAL); labelPaint.setTextSize(dp(9));
                canvas.drawText("SESSION COMPLETE  ·  " + Math.round(fraction * 100) + "%", cx, cy + dp(48), labelPaint);
                labelPaint.setColor(MUTED);
            } else {
                labelPaint.setColor(VIOLET); labelPaint.setTextSize(dp(8));
                canvas.drawText("A LITTLE PROGRESS, EVERY DAY", cx, cy + dp(48), labelPaint);
                labelPaint.setColor(MUTED);
            }
        }

        private RectF arcBoundsFor(float cx, float cy, float radius) {
            arcBounds.set(cx - radius, cy - radius, cx + radius, cy + radius);
            return arcBounds;
        }

    }

    @Override public void onBackPressed() {
        if (currentPage != 0 && pageViews.size() > 0) {
            showPage(0, true);
        } else {
            super.onBackPressed();
        }
    }

    private void addAction(View view, Runnable action) { view.setOnClickListener(v -> action.run()); }

    private EditText editText(String value, String hint) {
        EditText edit = new EditText(this);
        edit.setText(value);
        edit.setHint(hint);
        edit.setTextColor(WHITE);
        edit.setHintTextColor(Color.rgb(105, 127, 158));
        edit.setTextSize(13);
        edit.setPadding(dp(13), dp(10), dp(13), dp(10));
        edit.setGravity(Gravity.TOP | Gravity.START);
        edit.setBackground(round(Color.rgb(19, 30, 49), 13, OUTLINE));
        return edit;
    }

    private Button button(String label, int color) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor((color == TEAL || color == AMBER) ? BG : (color == VIOLET || color == RED ? Color.WHITE : WHITE));
        b.setTextSize(11);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        b.setAllCaps(false);
        b.setLetterSpacing(0.035f);
        b.setPadding(dp(10), dp(7), dp(10), dp(7));
        b.setMinHeight(dp(48));
        b.setBackground(rippleBackground(color, 14, (color == TEAL || color == VIOLET || color == AMBER) ? color : OUTLINE));
        b.setElevation(dp(2));
        b.setOnTouchListener((v, event) -> {
            if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                v.animate().scaleX(0.965f).scaleY(0.965f).translationZ(dp(4)).alpha(0.94f)
                        .setDuration(100).setInterpolator(new AccelerateDecelerateInterpolator()).start();
                v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            } else if (event.getAction() == android.view.MotionEvent.ACTION_UP
                    || event.getAction() == android.view.MotionEvent.ACTION_CANCEL) {
                v.animate().scaleX(1f).scaleY(1f).translationZ(0f).alpha(1f)
                        .setDuration(190).setInterpolator(new android.view.animation.OvershootInterpolator(1.15f)).start();
            }
            return false;
        });
        return b;
    }

    private RippleDrawable rippleBackground(int color, int radius, int stroke) {
        GradientDrawable content;
        if (color == TEAL || color == VIOLET || color == AMBER) {
            int lighter = blend(color, Color.WHITE, 0.16f);
            content = gradient(new int[]{lighter, color}, radius, stroke);
        } else {
            content = round(color, radius, stroke);
        }
        GradientDrawable mask = round(Color.WHITE, radius, Color.WHITE);
        int rippleColor = (color == TEAL || color == VIOLET || color == AMBER)
                ? Color.argb(62, 255, 255, 255) : Color.argb(44, 20, 164, 139);
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), content, mask);
    }

    private int blend(int from, int to, float amount) {
        float inverse = 1f - amount;
        return Color.rgb(
                Math.round(Color.red(from) * inverse + Color.red(to) * amount),
                Math.round(Color.green(from) * inverse + Color.green(to) * amount),
                Math.round(Color.blue(from) * inverse + Color.blue(to) * amount));
    }

    private Button smallButton(String label, int color) {
        Button b = button(label, color);
        b.setTextSize(10);
        return b;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable round(int color, int radiusDp, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        d.setStroke(dp(1), strokeColor);
        return d;
    }

    private GradientDrawable gradient(int[] colors, int radiusDp, int strokeColor) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        d.setCornerRadius(dp(radiusDp));
        // strokeColor is a primitive int, so it is never null.
        d.setStroke(dp(1), strokeColor);
        return d;
    }

    private void animateEntrance(View view, long delay) {
        view.setAlpha(0f);
        view.setTranslationY(dp(18));
        view.setScaleX(0.988f);
        view.setScaleY(0.988f);
        view.postDelayed(() -> view.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(520)
                .setInterpolator(new android.view.animation.OvershootInterpolator(0.72f)).start(), delay);
    }

    private void pulse(View view) {
        ObjectAnimator sx = ObjectAnimator.ofFloat(view, View.SCALE_X, 1f, 1.09f, 1f);
        ObjectAnimator sy = ObjectAnimator.ofFloat(view, View.SCALE_Y, 1f, 1.09f, 1f);
        sx.setDuration(2400); sy.setDuration(2400);
        sx.setRepeatCount(ValueAnimator.INFINITE); sy.setRepeatCount(ValueAnimator.INFINITE);
        sx.setInterpolator(new AccelerateDecelerateInterpolator()); sy.setInterpolator(new AccelerateDecelerateInterpolator());
        AnimatorSet set = new AnimatorSet(); set.playTogether(sx, sy); set.start();
    }

    private LinearLayout.LayoutParams fullWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private LinearLayout.LayoutParams fullWidth() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)); }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private float dp(float value) { return value * getResources().getDisplayMetrics().density; }

    private void hideKeyboard(View view) {
        if (view == null) return;
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(view.getWindowToken(), 0);
        view.clearFocus();
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            scanPickedImage(data.getData());
        } else if (requestCode == REQUEST_BLOCK_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri selected = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(selected, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                ProtectionPrefs.prefs(this).edit().putString(ProtectionPrefs.KEY_BLOCK_SCREEN_IMAGE, selected.toString()).apply();
                toast("Block-screen image saved");
            } catch (Exception ex) { toast("Could not save image permission: " + ex.getMessage()); }
        } else if (requestCode == REQUEST_VISUAL_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent scan = new Intent(this, VisualScreenProtectionService.class);
                scan.putExtra(VisualScreenProtectionService.EXTRA_RESULT_CODE, resultCode);
                scan.putExtra(VisualScreenProtectionService.EXTRA_RESULT_DATA, data);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(scan); else startService(scan);
                toast("Android approved the session. Live visual protection is starting.");
            } else {
                toast("Screen capture was not approved. Live visual protection remains off.");
            }
        }
        refreshStatuses();
    }
}
