# Third-party on-device model notice

VYRA can download `nudenet_320n_640_fp16.tflite` from the `enaser/blurguard-models` Hugging Face repository after the user taps **Install AI Model**. The model binary is not bundled in this source archive.

- Model name: `nudenet_320n_640_fp16.tflite`
- Upstream repository: `enaser/blurguard-models`
- Model license: AGPL-3.0, as stated by the upstream model repository.

Review the complete upstream license and attribution before redistribution. If you redistribute the model or a build containing it, comply with the upstream AGPL-3.0 terms and any other applicable requirements.
